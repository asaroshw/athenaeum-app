import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import logging
import re
import requests
import urllib.parse
from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET
from datetime import timedelta
from google import genai
from google.genai import types
from html import escape as html_escape

try:
    from statsmodels.tsa.arima.model import ARIMA
    HAS_ARIMA = True
except ImportError:
    HAS_ARIMA = False

# ============================================================
# 1. SETUP & CONFIGURATION
# ============================================================
logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger("athenaeum")
logging.getLogger('yfinance').setLevel(logging.CRITICAL)

st.set_page_config(
    page_title="Athenaeum Financial Intelligence", 
    page_icon="Logo.png", 
    layout="wide"
)

GEMINI_KEY = st.secrets.get("GEMINI_API_KEY", "")

# Session defaults
if "app_mode" not in st.session_state:
    st.session_state.app_mode = "equity"
if "selected_ipo" not in st.session_state:
    st.session_state.selected_ipo = None
if "ipo_detail" not in st.session_state:
    st.session_state.ipo_detail = None
if "ipo_bucket" not in st.session_state:
    st.session_state.ipo_bucket = None


GOLD, BG, CARD_BG, BORDER = "#EAB308", "#000000", "#0D0D0D", "#1F1F1F"
GREEN, RED, ORANGE, MUTED, BLUE, PURPLE = "#3FB950", "#F85149", "#F97316", "#8B949E", "#38BDF8", "#A855F7"

st.markdown(f"""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    html, body, [class*="st-"], .stApp, div, span, p, table, th, td, label {{ font-family: 'Inter', sans-serif !important; }}
    .stApp {{ background-color: {BG}; color: #E6E6E6; }}
    .swf-title-container {{ text-align: center; padding: 10px 0 20px 0; border-bottom: 1px solid {BORDER}; margin-bottom: 20px; }}
    .swf-title {{ font-size: 1.85em; font-weight: 800; color: #FFFFFF; letter-spacing: 0.5px; }}
    .swf-card {{ background-color: {CARD_BG}; border: 1px solid {BORDER}; border-radius: 10px; padding: 18px 20px; margin-bottom: 16px; }}
    .swf-h {{ color:{BLUE}; font-weight:700; font-size:1.05em; margin-bottom:6px; }}
    .swf-sub {{ color:{MUTED}; font-size:0.85em; margin-left:0px; }}
    .swf-check-pass {{ color: {GREEN}; }}
    .swf-check-fail {{ color: {RED}; }}
    .swf-check-na {{ color: {MUTED}; }}
    .swf-badge {{ background:{CARD_BG}; border:1px solid {BORDER}; padding:5px 12px; border-radius:6px; font-weight:700; font-size:0.85em; }}
    .swf-tag {{ background:#1c2333; border:1px solid {BORDER}; color:{MUTED}; padding:3px 9px; border-radius:5px; font-size:0.78em; margin-right:6px; display:inline-block; }}
    .swf-section-title {{ font-size: 1.6em; font-weight: 800; color: #FFFFFF; margin-top: 10px; padding-top: 14px; border-top: 2px solid {BORDER}; }}

    @media print {{
        section[data-testid="stSidebar"], header[data-testid="stHeader"], #MainMenu, footer,
        div[data-testid="stTextInput"], div[data-testid="stButton"], .stSpinner {{ display: none !important; }}
        .stApp {{ background-color: #ffffff !important; }}
        body, .stApp, p, div, span, td, th, li {{ color: #111111 !important; }}
        .swf-card {{ background-color: #ffffff !important; border: 1px solid #ccc !important; break-inside: avoid; }}
        .swf-check-pass {{ color: #15803d !important; }}
        .swf-check-fail {{ color: #b91c1c !important; }}
        .swf-h, .swf-section-title {{ color: #1e40af !important; }}
        .swf-title {{ color: #111111 !important; }}
    }}
</style>
""", unsafe_allow_html=True)

# ============================================================
# TOP SECTOR PEERS 
# ============================================================
SECTOR_PEERS = {
    "financial": ["BAJFINANCE.NS", "CHOLAFIN.NS", "SHRIRAMFIN.NS", "HDFCBANK.NS", "ICICIBANK.NS", "SBIN.NS"],
    "capex_intensive": ["LT.NS", "HAL.NS", "BEL.NS", "SIEMENS.NS", "ABB.NS", "CUMMINSIND.NS"],
    "cyclical": ["BOSCHLTD.NS", "MOTHERSON.NS", "UNOMINDA.NS", "MRF.NS", "TATAMOTORS.NS", "M&M.NS"],
    "materials": ["TATASTEEL.NS", "JSWSTEEL.NS", "HINDALCO.NS", "VEDL.NS", "ULTRACEMCO.NS"],
    "standard": ["RELIANCE.NS", "TCS.NS", "INFY.NS", "HUL.NS", "ITC.NS"] 
}

# ============================================================
# 2. CORE UTILITIES
# ============================================================
def to_float(val):
    if val in [None, "N/A", "", "None", "Stock doesn't pay dividends"]:
        return None
    if isinstance(val, bool) or (isinstance(val, float) and pd.isna(val)):
        return None
    if isinstance(val, (int, float)):
        return float(val)
    try:
        return float(str(val).replace('%', '').replace('x', '').replace('₹', '').replace(',', '').strip())
    except (TypeError, ValueError):
        return None

def is_valid_metric(val):
    if val in [None, "N/A", "", "-", "--", "None", "0", "0.00%", "0.00"]:
        return False
    return to_float(val) is not None

def fmt_indian_currency(val, currency="₹"):
    if not is_valid_metric(val):
        return "N/A"
    try:
        num = float(str(val).replace(',', '').replace('₹', '').replace('%', '').strip())
        if abs(num) >= 10000000:
            return f"{currency}{num/10000000:,.2f} Cr"
        elif abs(num) >= 100000:
            return f"{currency}{num/100000:,.2f} Lakh"
        return f"{currency}{num:,.2f}"
    except (TypeError, ValueError):
        return f"{currency} {val}"

def make_metric(value, source="unknown", period="unknown", as_of=None, currency="INR", confidence=0.7):
    """Lightweight provenance wrapper for auditable metrics."""
    return {
        "value": value,
        "source": source,
        "period": period,
        "as_of": as_of,
        "currency": currency,
        "confidence": float(confidence) if confidence is not None else 0.5,
    }

def metric_value(m):
    if isinstance(m, dict) and "value" in m:
        return m.get("value")
    return m

def resolve_name_to_ticker(stock_input):
    stock_str = str(stock_input).strip()
    if stock_str.isdigit():
        return stock_str + '.BO'
    try:
        res = requests.get(
            f"https://query2.finance.yahoo.com/v1/finance/search?q={stock_str}",
            headers={'User-Agent': 'Mozilla/5.0'}, timeout=5)
        if res.status_code == 200:
            for q in res.json().get('quotes', []):
                sym = q.get('symbol', '').upper()
                if sym.endswith('.NS') or sym.endswith('.BO'):
                    return sym
    except Exception as e:
        logger.warning("Ticker resolve failed for %s: %s", stock_input, e)
    upper = stock_str.upper().replace(" ", "")
    return upper if upper.endswith(('.NS', '.BO')) else upper + '.NS'

def rating_color(rating):
    r = (rating or "").upper()
    if "DON" in r and "BUY" in r: return RED
    if "OBSERVE" in r: return ORANGE
    if "BUY" in r: return GREEN
    return MUTED

def style_verdict_text(text):
    """Escape AI/user text first, then highlight known verdict tokens only."""
    if not text:
        return text
    safe = html_escape(str(text))
    return re.sub(
        r"(?i)\bDON.?T\s+BUY\b|\bOBSERVE\b|\bSTRONG\s+BUY\b|\bBUY\b|\bABSTAIN\b",
        lambda m: f'<span style="color:{rating_color(m.group(0))}; font-weight:bold;">{m.group(0)}</span>',
        safe,
    )

def fetch_google_news(query_term):
    try:
        safe_query = urllib.parse.quote(query_term)
        url = f"https://news.google.com/rss/search?q={safe_query}&hl=en-IN&gl=IN&ceid=IN:en"
        res = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=6)
        if res.status_code == 200:
            root = ET.fromstring(res.content)
            headlines = []
            for item in root.findall('.//item')[:6]:
                title = item.find('title')
                link = item.find('link')
                if title is not None and link is not None and title.text and link.text:
                    headlines.append({'title': title.text, 'link': link.text})
            return headlines
    except Exception as e:
        logger.warning("Google News fetch failed for %s: %s", query_term, e)
    return []

@st.cache_data(ttl=3600)
def get_dynamic_risk_free_rate():
    """Indian 10Y G-Sec yield as decimal.
    FMP primary → limited yfinance symbols that can plausibly represent Indian rates → static 6.5%.
    Never substitutes equity indices (e.g. GSPC) for a bond yield.
    """
    FMP_KEY = st.secrets.get("FMP_API_KEY", "")
    if FMP_KEY:
        for symbol in ["IN10Y", "GSIN10YR"]:
            try:
                r = requests.get(
                    f"https://financialmodelingprep.com/api/v3/historical-price-full"
                    f"/{symbol}?timeseries=5&apikey={FMP_KEY}",
                    headers={"Accept": "application/json"}, timeout=6)
                if r.status_code == 200:
                    hist = r.json().get("historical", [])
                    if hist:
                        yield_val = float(hist[0].get("close", 0))
                        if 3.0 <= yield_val <= 15.0:
                            return yield_val / 100.0
            except Exception as e:
                logger.warning("FMP RFR fetch failed for %s: %s", symbol, e)
    # Limited yfinance fallbacks — only symbols that can plausibly be bond yields
    for yf_sym in ["^IGB", "IN=F"]:
        try:
            bond = yf.Ticker(yf_sym)
            hist = bond.history(period="5d")
            if not hist.empty:
                val = float(hist["Close"].iloc[-1])
                if 3.0 <= val <= 15.0:
                    return val / 100.0
        except Exception as e:
            logger.warning("yfinance RFR fallback failed for %s: %s", yf_sym, e)
    # Static default approximating recent Indian 10Y G-Sec neighbourhood (not repo rate)
    return 0.065

# ============================================================
# 3. SECTOR DETECTION & NORMALIZATION PROFILES
# ============================================================
FINANCIAL_SECTOR_KEYWORDS = [
    "financial services", "bank", "nbfc", "insurance", "capital markets",
    "credit services", "diversified financials", "asset management",
    "mortgage finance", "consumer finance", "shadow banking",
]
CAPEX_INTENSIVE_KEYWORDS = [
    "industrial", "engineering", "infrastructure", "construction", "capital goods",
    "electrical equipment", "machinery", "railroad", "defense", "aerospace",
    "building products", "specialty industrial"
]
MATERIALS_KEYWORDS = ["steel", "metals", "mining", "materials", "chemicals", "cement", "iron", "pipes", "tubes"]
CYCLICAL_KEYWORDS = ["auto", "automobile", "tire", "tyre"]

def is_financial_sector(sector, industry):
    text = f"{sector or ''} {industry or ''}".lower()
    return any(kw in text for kw in FINANCIAL_SECTOR_KEYWORDS)

def classify_sector_profile(sector, industry):
    if is_financial_sector(sector, industry):
        return "financial"
    text = f"{sector or ''} {industry or ''}".lower()
    if any(kw in text for kw in MATERIALS_KEYWORDS):
        return "materials"
    if any(kw in text for kw in CAPEX_INTENSIVE_KEYWORDS):
        return "capex_intensive"
    if any(kw in text for kw in CYCLICAL_KEYWORDS):
        return "cyclical"
    return "standard"

STANDARD_REVENUE_KEYS = ['Total Revenue', 'Operating Revenue']
BANK_REVENUE_KEYS = ['Total Revenue', 'Total Operating Income', 'Interest Income',
                      'Total Interest Income', 'Operating Revenue']
INTEREST_INCOME_KEYS = ['Interest Income', 'Total Interest Income']

# ============================================================
# 4. QUALITATIVE SIGNAL SCANNER
# ============================================================
CATALYST_KEYWORDS = ['acqui', 'profit', 'surge', 'turnaround', 'wins', ' win ', 'order book',
                      'expansion', 'partnership', 'record revenue', 'upgrade', 'beat estimates',
                      'demerger', 'stake sale', 'contract']
RISK_KEYWORDS = ['fraud', 'resign', 'default', 'probe', 'raid', 'downgrade', 'scam',
                  'investigation', 'lawsuit', 'bankruptcy', 'insolvency', 'delisting']
ORDER_BOOK_KEYWORDS = ['order book', 'order win', 'wins order', 'contract win', 'crore order',
                        'export order', 'multi-year contract', 'l1 bidder', 'lowest bidder',
                        'capex expansion', 'capacity expansion', 'new plant', 'guidance']
GROWTH_PCT_PATTERN = re.compile(r'(\d{1,2})\s*%\s*(?:growth|guidance)|(?:growth|guidance).{0,25}?(\d{1,2})\s*%', re.IGNORECASE)

def scan_news_sentiment(recent_news, business_summary):
    """Title-only keyword scan with per-title negation and capped impact.
    Optional Stage-2 LLM classification when GEMINI_KEY is available.
    """
    NEGATION = ['denies', 'deny', 'clears', 'cleared', 'no evidence', 'exonerated',
                'completed successfully', 'dismissed', 'baseless', 'unfounded',
                'false report', 'not involved', 'refutes', 'rejects claims']
    titles = [n.get('title', '') for n in (recent_news or [])]
    catalyst_hits, risk_hits, confirmed_risks = [], [], []
    for t in titles:
        tl = t.lower()
        cats = [kw.strip() for kw in CATALYST_KEYWORDS if kw in tl]
        risks = [kw.strip() for kw in RISK_KEYWORDS if kw in tl]
        catalyst_hits.extend(cats)
        risk_hits.extend(risks)
        has_neg = any(neg in tl for neg in NEGATION)
        if risks and not has_neg:
            confirmed_risks.extend(risks)
    catalyst_hits = sorted(set(catalyst_hits))
    risk_hits = sorted(set(risk_hits))
    confirmed_risks = sorted(set(confirmed_risks))
    bonus, notes = 0, []
    if len(catalyst_hits) >= 2:
        bonus += 4
        notes.append(f"News catalyst keywords (+4, auxiliary): {', '.join(catalyst_hits[:4])}.")
    elif len(catalyst_hits) == 1:
        bonus += 2
        notes.append(f"News catalyst keyword (+2, auxiliary): {catalyst_hits[0]}.")
    if confirmed_risks:
        bonus -= 6
        notes.append(f"Confirmed risk keywords in news (−6, auxiliary): {', '.join(confirmed_risks[:3])}.")
    elif risk_hits:
        notes.append(f"Risk keywords appear with negation — no penalty ({', '.join(risk_hits[:3])}).")

    # Stage 2: optional LLM materiality classification (fails soft)
    llm_adj = _llm_news_score(titles[:5])
    if llm_adj is not None:
        adj, llm_note = llm_adj
        bonus = max(min(bonus + adj, 5), -5)  # news is auxiliary only
        notes.append(llm_note)

    if bonus != 0 or notes:
        notes.append("News signal is auxiliary only; not a substitute for filings or primary research.")
    return bonus, notes

def _llm_news_score(titles):
    """Optional Gemini classification of headline materiality. Returns (adj, note) or None."""
    if not GEMINI_KEY or not titles:
        return None
    try:
        client = genai.Client(api_key=GEMINI_KEY)
        prompt = (
            "Classify these stock news headlines for equity materiality. "
            "Return ONLY JSON: {\"sentiment\": -1 to 1, \"materiality\": 0 to 1, "
            "\"confidence\": 0 to 1, \"one_line\": \"...\"}. Headlines:\n"
            + "\n".join(f"- {t}" for t in titles)
        )
        resp = client.models.generate_content(
            model="gemini-2.0-flash",
            contents=prompt,
            config=types.GenerateContentConfig(temperature=0.1),
        )
        text = (resp.text or "").strip()
        m = re.search(r'\{[^{}]+\}', text, re.DOTALL)
        if not m:
            return None
        import json
        data = json.loads(m.group(0))
        sent = float(data.get("sentiment", 0))
        mat = float(data.get("materiality", 0))
        conf = float(data.get("confidence", 0))
        score = sent * mat * conf * 10  # roughly −10..+10
        score = max(min(score, 8), -10)
        note = (f"LLM news overlay ({score:+.1f}): sentiment={sent:.2f}, "
                f"materiality={mat:.2f}, conf={conf:.2f}. {data.get('one_line', '')}")
        return round(score), note
    except Exception as e:
        logger.warning("LLM news classification failed: %s", e)
        return None

def extract_order_book_signal(recent_news, business_summary, trailing_revenue_cr=None):
    """Detect order-book/guidance language. Never treat headline % as earnings growth.
    Returns (hits, guidance_hint_pct) where guidance_hint is heavily discounted and optional.
    """
    titles = [n.get('title', '') for n in (recent_news or [])]
    text = " ".join(titles)
    text_lower = text.lower()
    order_hits = sorted(set(kw for kw in ORDER_BOOK_KEYWORDS if kw in text_lower))
    growth_pct_found = None
    match = GROWTH_PCT_PATTERN.search(text)
    if match:
        val = match.group(1) or match.group(2)
        try:
            v = float(val)
            # Headline "20% growth" is not EPS growth — only allow as a soft hint, capped low
            if 5 <= v <= 40:
                growth_pct_found = min(v * 0.4, 12.0)  # 40% of headline, max 12pp contribution
        except (TypeError, ValueError) as e:
            logger.debug("Order-book growth parse failed: %s", e)
    if order_hits and trailing_revenue_cr and trailing_revenue_cr > 0:
        m_size = re.search(r'(?:rs\.?|inr|₹)\s*([\d,]+)\s*(?:crore|cr)', text, re.IGNORECASE)
        if m_size:
            try:
                order_cr = float(m_size.group(1).replace(",", ""))
                if order_cr / trailing_revenue_cr < 0.05:
                    growth_pct_found = None  # immaterial order
            except (TypeError, ValueError) as e:
                logger.debug("Order size parse failed: %s", e)
    return order_hits, growth_pct_found

# ============================================================
# 5. CHECKLISTS
# ============================================================
def valuation_checks(m):
    pe = to_float(m.get('pe_ratio'))
    peg = to_float(m.get('peg_ratio'))
    pat_yoy = to_float(m.get('pat_yoy'))
    pb = to_float(m.get('pb_ratio'))
    ev_ebitda = to_float(m.get('ev_ebitda'))
    is_fin = m.get('is_financial_sector', False)
    checks = []

    if pe is not None:
        if pe < 0:
            checks.append(("Profitable on a P/E basis", False,
                            f"P/E is negative ({pe:.2f}x) — the company is currently loss-making."))
        else:
            threshold = 45 if (pat_yoy is not None and pat_yoy > 30) else 25
            checks.append((f"Reasonable P/E (<{threshold}x{' — growth-adjusted' if threshold==45 else ''})",
                            pe < threshold, f"Trailing P/E of {pe:.2f}x"))

    if peg is not None:
        if peg < 0:
            checks.append(("Positive PEG", False,
                            f"PEG is negative ({peg:.2f}) — implies shrinking earnings or a loss-making company."))
        elif pe is not None and pe > 0 and pat_yoy is not None and pat_yoy > 0:
            checks.append(("Attractive PEG (<1.5)", peg < 1.5, f"PEG ratio of {peg:.2f}"))

    if pb is not None:
        threshold = 3.0 if is_fin else 5.0
        checks.append((f"Reasonable P/B (<{threshold:g}x)", 0 < pb < threshold, f"Price-to-Book of {pb:.2f}x"))

    if is_fin and pb is not None and m.get('justified_pb'):
        jpb = m['justified_pb']
        checks.append(("P/B vs Excess-ROE Justified P/B", pb < jpb,
                        f"Actual P/B {pb:.2f}x vs a model-justified P/B of {jpb:.2f}x"))

    if not is_fin and ev_ebitda is not None:
        if ev_ebitda < 0:
            checks.append(("Positive EV/EBITDA", False,
                            f"EV/EBITDA is negative ({ev_ebitda:.2f}x) — implies operating losses."))
        else:
            checks.append(("Reasonable EV/EBITDA (<15x)", ev_ebitda < 15, f"EV/EBITDA of {ev_ebitda:.2f}x"))

    return checks

def past_performance_checks(m):
    yoy, qoq = to_float(m.get('pat_yoy')), to_float(m.get('pat_qoq'))
    roe, margin = to_float(m.get('roe')), to_float(m.get('net_margin'))
    opm = to_float(m.get('operating_margin'))
    rev_cagr = to_float(m.get('revenue_cagr'))
    sector_profile = m.get('sector_profile', 'standard')
    checks = []
    if yoy is not None:
        checks.append(("Positive Earnings Growth (YoY)", yoy > 0, f"PAT YoY growth of {yoy:.2f}%"))
    if yoy is not None and qoq is not None:
        # Fix 4: compare recent YoY to prior YoY (same timescale)
        prior_yoy = to_float(m.get("pat_yoy_prior"))
        if prior_yoy is not None:
            checks.append(("Accelerating YoY Earnings Growth", yoy > prior_yoy,
                            f"Recent YoY {yoy:.1f}% vs prior year YoY {prior_yoy:.1f}%"))
        else:
            checks.append(("Positive YoY Earnings Growth", yoy > 0,
                            f"PAT YoY growth of {m.get('pat_yoy')} (prior year unavailable for acceleration check)"))
    if roe is not None:
        checks.append(("Strong Return on Equity (>15%)", roe > 15, f"ROE of {roe:.2f}%"))
    if margin is not None:
        if sector_profile in ["cyclical", "materials", "capex_intensive"] and opm is not None and opm > 15 and rev_cagr is not None and rev_cagr > 8:
            checks.append(("Healthy Net Margin (cyclical-adjusted, >6%)", margin > 6,
                            f"Net margin of {margin:.2f}% — bar relaxed given strong OPM/CAGR."))
        else:
            checks.append(("Healthy Net Margin (>10%)", margin > 10, f"Net margin of {margin:.2f}%"))
    return checks

def financial_health_checks(m):
    de = to_float(m.get('debt_to_equity'))
    ic = to_float(m.get('interest_coverage'))
    is_fin = m.get('is_financial_sector', False)
    checks = []
    if de is not None:
        if de < 0:
            checks.append(("Positive Shareholder Equity", False,
                            f"Debt-to-equity is negative ({de:.2f}) — implies negative shareholders' equity."))
        else:
            threshold, label = (10.0, "Leverage in line with a lending-book business model (D/E < 10x)") if is_fin \
                else (1.0, "Low Leverage (D/E < 1.0)")
            checks.append((label, de < threshold, f"Debt-to-equity of {de:.2f}"))
    if ic is not None:
        checks.append(("Comfortable Interest Coverage (>3x)", ic > 3, f"EBIT covers interest expense {ic:.2f}x"))
    if is_fin and m.get('nim_proxy') is not None:
        nim = m['nim_proxy']
        checks.append(("Positive Net Interest Margin (approx.)", nim > 0,
                        f"Approximate NIM of {nim:.2f}%"))
    return checks

def dividend_checks(m):
    dy_str = str(m.get('dividend_yield', ''))
    if "doesn't pay" in dy_str.lower():
        return [("Notable Dividend (>1.5%)", False, "Stock doesn't pay dividends")]
    dy = to_float(dy_str)
    return [("Notable Dividend (>1.5%)", dy is not None and dy > 1.5, f"Dividend yield: {dy:.2f}%" if dy else "N/A")]

def _clamp01(x):
    return max(0.0, min(1.0, float(x)))

def _piecewise_score(value, good, excellent, higher_is_better=True):
    """Map a continuous metric to 0–100.
    - At `good` → ~60
    - At `excellent` → ~100
    - Midpoint between bad and good → ~30
    """
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None
    v = float(value)
    if not higher_is_better:
        # Invert: lower is better (e.g. PE, D/E)
        if v <= excellent:
            return 100.0
        if v >= good * 2.5:
            return 5.0
        if v <= good:
            # excellent..good → 100..60
            span = max(good - excellent, 1e-9)
            return 60.0 + 40.0 * _clamp01((good - v) / span)
        # good..2.5*good → 60..5
        span = max(good * 1.5, 1e-9)
        return 5.0 + 55.0 * _clamp01((good * 2.5 - v) / span)
    # higher is better
    if v >= excellent:
        return 100.0
    if v <= 0:
        return 5.0
    if v >= good:
        span = max(excellent - good, 1e-9)
        return 60.0 + 40.0 * _clamp01((v - good) / span)
    span = max(good, 1e-9)
    return 5.0 + 55.0 * _clamp01(v / span)

def continuous_valuation_score(m):
    """Continuous 0–100 valuation score (sector-aware thresholds)."""
    pe = to_float(m.get('pe_ratio'))
    peg = to_float(m.get('peg_ratio'))
    pb = to_float(m.get('pb_ratio'))
    ev_ebitda = to_float(m.get('ev_ebitda'))
    is_fin = m.get('is_financial_sector', False)
    pat_yoy = to_float(m.get('pat_yoy'))
    parts = []
    if pe is not None and pe > 0:
        good_pe = 35 if (pat_yoy and pat_yoy > 25) else 22
        parts.append(_piecewise_score(pe, good=good_pe, excellent=good_pe * 0.55, higher_is_better=False))
    if peg is not None and peg > 0:
        parts.append(_piecewise_score(peg, good=1.8, excellent=0.9, higher_is_better=False))
    if pb is not None and pb > 0:
        good_pb = 2.5 if is_fin else 4.0
        parts.append(_piecewise_score(pb, good=good_pb, excellent=good_pb * 0.45, higher_is_better=False))
    if not is_fin and ev_ebitda is not None and ev_ebitda > 0:
        parts.append(_piecewise_score(ev_ebitda, good=14, excellent=7, higher_is_better=False))
    if is_fin and pb is not None and m.get('justified_pb'):
        jpb = to_float(m.get('justified_pb'))
        if jpb and jpb > 0:
            ratio = pb / jpb
            parts.append(_piecewise_score(ratio, good=1.15, excellent=0.7, higher_is_better=False))
    valid = [p for p in parts if p is not None]
    return round(sum(valid) / len(valid)) if valid else None

def continuous_past_score(m):
    yoy = to_float(m.get('pat_yoy'))
    roe = to_float(m.get('roe'))
    margin = to_float(m.get('net_margin'))
    rev_cagr = to_float(m.get('revenue_cagr'))
    sector_profile = m.get('sector_profile', 'standard')
    parts = []
    if yoy is not None:
        parts.append(_piecewise_score(yoy, good=12, excellent=30, higher_is_better=True))
    if roe is not None:
        parts.append(_piecewise_score(roe, good=15, excellent=25, higher_is_better=True))
    if margin is not None:
        good_m = 6 if sector_profile in ["cyclical", "materials", "capex_intensive"] else 10
        parts.append(_piecewise_score(margin, good=good_m, excellent=good_m * 1.8, higher_is_better=True))
    if rev_cagr is not None:
        parts.append(_piecewise_score(rev_cagr, good=8, excellent=18, higher_is_better=True))
    valid = [p for p in parts if p is not None]
    return round(sum(valid) / len(valid)) if valid else None

def continuous_health_score(m):
    de = to_float(m.get('debt_to_equity'))
    ic = to_float(m.get('interest_coverage'))
    is_fin = m.get('is_financial_sector', False)
    parts = []
    if de is not None:
        if de < 0:
            parts.append(10.0)
        else:
            good_de = 8.0 if is_fin else 0.8
            parts.append(_piecewise_score(de, good=good_de, excellent=good_de * 0.35, higher_is_better=False))
    if ic is not None and ic > 0:
        parts.append(_piecewise_score(ic, good=4, excellent=12, higher_is_better=True))
    if is_fin and m.get('nim_proxy') is not None:
        nim = to_float(m.get('nim_proxy'))
        if nim is not None:
            parts.append(_piecewise_score(nim, good=2.0, excellent=4.0, higher_is_better=True))
    valid = [p for p in parts if p is not None]
    return round(sum(valid) / len(valid)) if valid else None

def score_from_checks(checks):
    """Return (score 0-100 or None, n_available, n_possible).
    Binary checklist retained for UI transparency; continuous scores drive the model.
    Missing checks still count against completeness.
    """
    if not checks:
        return None, 0, 0
    vals = [c[1] for c in checks if c[1] is not None]
    n_available = len(vals)
    n_possible = len(checks)
    if n_available == 0:
        return None, 0, n_possible
    raw = 100 * sum(1 for v in vals if v) / n_available
    completeness = n_available / max(n_possible, 1)
    adjusted = raw * (0.70 + 0.30 * completeness)
    return round(adjusted), n_available, n_possible

def render_checks(checks):
    if not checks:
        return "<div class='swf-check-na'>&#8213; Not enough data to run this checklist.</div>"
    html = ""
    for label, status, desc in checks:
        icon, cls = ("&#9989;", "swf-check-pass") if status else ("&#10060;", "swf-check-fail")
        html += f'<div style="padding:5px 0;"><span class="{cls}">{icon} <b>{html_escape(str(label))}</b></span><div class="swf-sub">{html_escape(str(desc))}</div></div>'
    return html

def compute_fundamental_score(val_score, past_score, health_score, is_financial,
                              val_avail=0, past_avail=0, health_avail=0,
                              val_poss=0, past_poss=0, health_poss=0):
    weights = {"val": 0.45, "past": 0.35, "health": 0.20} if is_financial else {"val": 0.35, "past": 0.35, "health": 0.30}
    scores = {"val": val_score, "past": past_score, "health": health_score}
    available = {k: v for k, v in scores.items() if v is not None}
    if not available:
        return None, 0.0  # unknown fundamentals — not a zero score
    total_w = sum(weights[k] for k in available)
    fund = round(sum(weights[k] * v for k, v in available.items()) / total_w, 1)
    # Overall data completeness across the three pillars
    total_avail = val_avail + past_avail + health_avail
    total_poss = val_poss + past_poss + health_poss
    completeness = round(100 * total_avail / max(total_poss, 1), 1) if total_poss else 0.0
    return fund, completeness

# ============================================================
# 6. QUANTITATIVE COMPOSITE ENGINE
# ============================================================
EQUITY_RISK_PREMIUM = 0.055
TERMINAL_GROWTH_PCT = 5.0

def calculate_vwap_support(df):
    d = df.dropna(subset=['Close', 'Volume'])
    if d.empty: return None
    d = d.copy()
    d['PriceBin'] = pd.cut(d['Close'], bins=20)
    vol_by_bin = d.groupby('PriceBin', observed=True)['Volume'].sum()
    if vol_by_bin.empty: return None
    return vol_by_bin.idxmax().mid

def calculate_atr(df, period=14):
    if df is None or len(df) <= period: return None
    high_low = df['High'] - df['Low']
    high_close = (df['High'] - df['Close'].shift()).abs()
    low_close = (df['Low'] - df['Close'].shift()).abs()
    val = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1).rolling(period).mean().iloc[-1]
    return float(val) if pd.notna(val) else None

def compute_technical_score(hist, current_price=None):
    """Grouped technical score: Trend / Momentum (rel. to Nifty when available) / Risk / Volume.
    Returns (score, regime_label, horizon_hint, drift). Horizon is a thesis placeholder, not a prediction.
    """
    if hist is None or hist.empty or 'Close' not in hist.columns:
        return 50.0, "NEUTRAL", "Thesis-dependent", None
    closes = hist['Close'].dropna()
    if len(closes) < 30:
        return 50.0, "NEUTRAL", "Thesis-dependent", None
    price = float(current_price) if current_price else float(closes.iloc[-1])

    # --- Group 1: Trend (SMA structure + mild drift, averaged) ---
    trend_parts = []
    sma20 = closes.rolling(20).mean().iloc[-1] if len(closes) >= 20 else None
    sma50 = closes.rolling(50).mean().iloc[-1] if len(closes) >= 50 else None
    sma200 = closes.rolling(200).mean().iloc[-1] if len(closes) >= 200 else None
    trend_pts = 50.0
    if sma50 is not None and pd.notna(sma50):
        trend_pts += 15 if price > sma50 else -15
    if sma200 is not None and pd.notna(sma200):
        trend_pts += 15 if price > sma200 else -20
    if sma20 is not None and sma50 is not None and pd.notna(sma20) and pd.notna(sma50):
        trend_pts += 10 if sma20 > sma50 else -10
    trend_parts.append(max(0, min(100, trend_pts)))
    drift = None
    try:
        log_prices = np.log(closes.values.astype(float))
        if np.all(np.isfinite(log_prices)) and len(log_prices) > 30:
            slope, _ = np.polyfit(np.arange(len(log_prices)), log_prices, 1)
            drift = float(np.exp(slope * 252) - 1)
            trend_parts.append(max(0, min(100, 50 + max(min(drift * 60, 25), -25))))
    except Exception as e:
        logger.debug("Drift calc failed: %s", e)
    trend_score = sum(trend_parts) / len(trend_parts)

    # --- Group 2: Momentum (absolute + relative vs Nifty when available) ---
    def _ret(series, n):
        if len(series) > n and float(series.iloc[-n]) > 0:
            return (float(series.iloc[-1]) / float(series.iloc[-n]) - 1.0) * 100
        return None
    r3 = _ret(closes, 63)
    r6 = _ret(closes, 126)
    # Relative to Nifty 50
    nifty_r3 = nifty_r6 = None
    try:
        n_hist = yf.Ticker("^NSEI").history(period="1y")
        if n_hist is not None and not n_hist.empty and "Close" in n_hist.columns:
            nc = n_hist["Close"].dropna()
            nifty_r3 = _ret(nc, 63)
            nifty_r6 = _ret(nc, 126)
    except Exception as e:
        logger.debug("Nifty relative momentum unavailable: %s", e)
    mom_parts = []
    if r3 is not None:
        abs_m = 50 + max(min(r3 * 0.9, 20), -20)
        if nifty_r3 is not None:
            excess = r3 - nifty_r3
            abs_m = 50 + max(min(excess * 1.2, 25), -25)
        mom_parts.append(max(0, min(100, abs_m)))
    if r6 is not None:
        abs_m = 50 + max(min(r6 * 0.7, 18), -18)
        if nifty_r6 is not None:
            excess = r6 - nifty_r6
            abs_m = 50 + max(min(excess * 1.0, 22), -22)
        mom_parts.append(max(0, min(100, abs_m)))
    mom_score = sum(mom_parts) / len(mom_parts) if mom_parts else 50.0

    # --- Group 3: Risk / drawdown ---
    high_52 = float(closes.tail(252).max()) if len(closes) >= 50 else float(closes.max())
    dd = (price / high_52 - 1.0) * 100 if high_52 > 0 else 0
    risk_score = max(0, min(100, 80 + dd * 1.5))

    # --- Group 4: Volume ---
    vol_score = 50.0
    if 'Volume' in hist.columns and len(hist) >= 20:
        vol = hist['Volume'].dropna()
        if len(vol) >= 20:
            v_ratio = float(vol.iloc[-5:].mean() / max(vol.iloc[-20:].mean(), 1))
            vol_score = max(0, min(100, 50 + max(min((v_ratio - 1.0) * 40, 25), -20)))

    # Weighted groups (not 6 independent additives)
    tech = round(0.35 * trend_score + 0.30 * mom_score + 0.20 * risk_score + 0.15 * vol_score, 1)

    if tech >= 65:
        regime, horizon = "POSITIVE", "Thesis-dependent (constructive technical regime)"
    elif tech <= 35:
        regime, horizon = "NEGATIVE", "Thesis-dependent (weak technical regime)"
    else:
        regime, horizon = "NEUTRAL", "Thesis-dependent"
    return tech, regime, horizon, drift

def justified_pb_fair_value(roe_pct, ke_pct, growth_pct, book_value_per_share, pb_floor=0.4, pb_cap=None):
    """Fix 12: pb_cap is dynamic — high-ROE institutions (ROE>20%) justify >8x P/B."""
    if pb_cap is None:
        pb_cap = 12.0 if (roe_pct and roe_pct > 20) else 8.0
    if not book_value_per_share or book_value_per_share <= 0 or roe_pct is None:
        return None, None
    roe, ke, g = roe_pct / 100, ke_pct / 100, growth_pct / 100
    if ke <= g:
        g = ke - 0.02
    jpb = 1 + (roe - ke) / (ke - g)
    jpb = min(max(jpb, pb_floor), pb_cap)
    return round(jpb, 2), round(jpb * book_value_per_share, 2)

def ddm_fair_value(dividend_per_share, ke_pct, growth_pct):
    if not dividend_per_share or dividend_per_share <= 0:
        return None
    ke, g = ke_pct / 100, growth_pct / 100
    if ke <= g:
        g = ke - 0.02
    return round((dividend_per_share * (1 + g)) / (ke - g), 2)

def composite_verdict(fundamental_score, margin_of_safety, drift, arima_direction=None,
                      forced_intrinsic_adjustment=0, qualitative_bonus=0):
    W_FUNDAMENTAL, W_INTRINSIC, W_TECHNICAL = 0.42, 0.38, 0.20
    intrinsic_score = min(max(50 + margin_of_safety * 120, 0), 100)
    intrinsic_score = min(max(intrinsic_score + forced_intrinsic_adjustment, 0), 100)
    # Cap drift contribution so extreme trends cannot dominate
    capped_drift = max(min(drift or 0, 0.40), -0.40)
    tech_score = min(max(50 + capped_drift * 80, 0), 100)
    # ARIMA is a weak confirmatory signal only (±5, not ±10)
    if arima_direction == "UP":
        tech_score = min(100, tech_score + 5)
    elif arima_direction == "DOWN":
        tech_score = max(0, tech_score - 5)
    # Qualitative bonus/penalty also capped
    q_bonus = max(min(qualitative_bonus or 0, 5), -5)
    # Missing fundamentals should not silently become zero in this helper
    fund = 50.0 if fundamental_score is None else fundamental_score  # neutral placeholder; pipeline overrides
    composite = W_FUNDAMENTAL * fund + W_INTRINSIC * intrinsic_score + W_TECHNICAL * tech_score
    composite = min(max(composite + q_bonus, 0), 100)
    if composite >= 75: verdict = "STRONG BUY"
    elif composite >= 60: verdict = "BUY"
    elif composite >= 40: verdict = "OBSERVE"
    else: verdict = "DON'T BUY"
    return round(composite, 1), verdict, round(intrinsic_score, 1), round(tech_score, 1)

VERDICT_RANK = {"DON'T BUY": 0, "OBSERVE": 1, "BUY": 2, "STRONG BUY": 3}

def apply_tiered_sanity_veto(verdict, target_price, current_price, notes, growth_pct=None):
    if target_price is None or not current_price:
        return verdict
        
    downside_pct = (current_price - target_price) / current_price
    upside_pct = (target_price - current_price) / current_price
    
    if downside_pct > 0.15:
        if verdict != "DON'T BUY":
            notes.append(f"Model indicates {round(downside_pct*100,1)}% downside. Treated as OBSERVE or DON'T BUY based on fundamental strength.")
        return "DON'T BUY" if downside_pct > 0.40 else "OBSERVE"
        
    elif downside_pct > 0:
        if VERDICT_RANK.get(verdict, 1) > VERDICT_RANK["OBSERVE"]:
            notes.append(f"Downgraded to OBSERVE: the modeled target price is {round(downside_pct*100,1)}% below the current price.")
            return "OBSERVE"
            
    # Fix 2: ceiling scales with verified growth_pct instead of a static 150%
    g = growth_pct if (growth_pct and growth_pct > 0) else 0
    max_upside = 2.50 if g >= 25 else (2.00 if g >= 15 else 1.50)
    if upside_pct > max_upside:
        notes.append(
            f"Upside of +{round(upside_pct*100,1)}% exceeds the growth-adjusted ceiling "
            f"of {round(max_upside*100,0):.0f}% (verified growth={round(g,1)}%). "
            f"Flagged as possible data anomaly — downgraded to OBSERVE for human review."
        )
        if VERDICT_RANK.get(verdict, 1) > VERDICT_RANK["OBSERVE"]:
            return "OBSERVE"   # OBSERVE not DON'T BUY: surfaces signal, doesn't bury it
            
    return verdict

def compute_multi_model_values(
    current_price, ke_pct, growth_pct, financial, book_value_per_share, dividend_per_share,
    roe_pct, effective_eps, resolved_pe, fcf_history, shares, precomputed_jpb, precomputed_ddm,
    sector_profile, pat_yoy_pct,
):
    """Multi-model valuation with one explicit forecast growth and non-overlapping model families.
    Near-term growth may exceed Ke; only terminal growth is constrained below Ke.
    DCF is a simplified FCF extrapolation (not a full operating DCF).
    """
    models = {}
    ke = ke_pct / 100.0
    # Explicit near-term forecast (may exceed Ke); used for stage-1 projections
    near_term_g = min(max(float(growth_pct) / 100.0, 0.02), 0.40)
    # Terminal growth always below Ke
    tg = min(TERMINAL_GROWTH_PCT / 100.0, max(ke - 0.02, 0.02))
    # Fade path for multi-year models: y1-3 near-term, y4-5 toward terminal
    def growth_at_year(t):
        if t <= 3:
            return near_term_g
        if t == 4:
            return 0.65 * near_term_g + 0.35 * tg
        return 0.35 * near_term_g + 0.65 * tg

    if financial:
        # Prefer independent family members — do NOT also emit Blended + JPB + DDM
        jpb_ratio, jpb_value = (precomputed_jpb if precomputed_jpb is not None
                               else justified_pb_fair_value(roe_pct, ke_pct, growth_pct, book_value_per_share))
        ddm_val = precomputed_ddm if precomputed_ddm is not None else ddm_fair_value(dividend_per_share, ke_pct, growth_pct)
        if jpb_value:
            models["Justified P/B"] = float(jpb_value)
        if ddm_val:
            models["DDM"] = float(ddm_val)
        # Residual income is a separate accounting-family cross-check (below)
    else:
        # Income-multiple family: use model_growth (growth_pct), not PAT YoY override
        if effective_eps and effective_eps > 0:
            g_eps = near_term_g  # same hierarchy as pipeline
            term_pe = 28 if growth_pct >= 25 else (22 if growth_pct >= 15 else 16)
            eps = float(effective_eps)
            for t in range(1, 4):
                eps *= (1 + growth_at_year(t))
            models["3Y Forward EPS"] = (eps * term_pe) / ((1 + ke) ** 3)

            hist_pe = resolved_pe if (resolved_pe and resolved_pe > 0) else 18.0
            target_pe = min(max(hist_pe, 12), 28)
            models["Trailing EPS × Target P/E"] = effective_eps * target_pe

        # Simplified FCF DCF (extrapolation — not full operating DCF)
        if fcf_history is not None and len(fcf_history) > 0 and shares and shares > 0:
            try:
                fcf_chrono = fcf_history.iloc[::-1] if hasattr(fcf_history, "iloc") else list(reversed(list(fcf_history)))
                fcf_vals = [float(x) for x in fcf_chrono if x is not None and not (isinstance(x, float) and np.isnan(x))]
                if fcf_vals:
                    weights = np.arange(1, len(fcf_vals) + 1, dtype=float)
                    avg_fcf = float(np.average(fcf_vals, weights=weights))
                    fcf_ps = avg_fcf / shares
                    if fcf_ps > 0:
                        pv = 0.0
                        fcf_t = fcf_ps
                        for t in range(1, 6):
                            fcf_t *= (1 + growth_at_year(t))
                            pv += fcf_t / ((1 + ke) ** t)
                        tv = (fcf_t * (1 + tg)) / (ke - tg)
                        models["Simplified FCF DCF"] = pv + tv / ((1 + ke) ** 5)
            except Exception as e:
                logger.warning("Multi-model DCF failed: %s", e)

        if book_value_per_share and book_value_per_share > 0:
            models["Book × 0.8"] = book_value_per_share * 0.80

    # Accounting-family residual income (simplified cross-check)
    if book_value_per_share and book_value_per_share > 0 and roe_pct is not None:
        excess = (roe_pct / 100.0) - ke
        if excess > -0.05:
            ri = 0.0
            bv = book_value_per_share
            for t in range(1, 6):
                ri += (excess * bv) / ((1 + ke) ** t)
                bv *= (1 + min(near_term_g, 0.12))
            models["Simplified Residual Income"] = book_value_per_share + ri

    # Non-overlapping family weights (one representative per economic family where possible)
    if financial or sector_profile == "financial":
        weight_map = {
            "Justified P/B": 0.50, "DDM": 0.25, "Simplified Residual Income": 0.25,
            "Book × 0.8": 0.05, "Defensive Haircut 25%": 0.05,
        }
        preference = ["Justified P/B", "DDM", "Simplified Residual Income", "Book × 0.8"]
    elif sector_profile in ("capex_intensive", "materials", "cyclical"):
        weight_map = {
            "Simplified FCF DCF": 0.45, "3Y Forward EPS": 0.30,
            "Trailing EPS × Target P/E": 0.15, "Simplified Residual Income": 0.10,
            "Book × 0.8": 0.05, "Defensive Haircut 25%": 0.05,
        }
        preference = ["Simplified FCF DCF", "3Y Forward EPS", "Trailing EPS × Target P/E",
                      "Simplified Residual Income", "Book × 0.8"]
    else:
        weight_map = {
            "Simplified FCF DCF": 0.35, "3Y Forward EPS": 0.30,
            "Trailing EPS × Target P/E": 0.20, "Simplified Residual Income": 0.15,
            "Book × 0.8": 0.05, "Defensive Haircut 25%": 0.05,
            "Justified P/B": 0.20, "DDM": 0.15,
        }
        preference = ["Simplified FCF DCF", "3Y Forward EPS", "Trailing EPS × Target P/E",
                      "Simplified Residual Income", "Justified P/B", "DDM", "Book × 0.8"]

    primary_name, primary_val = None, None
    for name in preference:
        if name in models and models[name] and models[name] > 0:
            primary_name, primary_val = name, models[name]
            break
    if primary_val is None and current_price:
        models["Defensive Haircut 25%"] = current_price * 0.75
        primary_name, primary_val = "Defensive Haircut 25%", current_price * 0.75

    core = {k: v for k, v in models.items() if v and v > 0 and k not in ("Book × 0.8", "Defensive Haircut 25%")}
    if not core:
        core = {k: v for k, v in models.items() if v and v > 0}
    wsum = wval = 0.0
    for k, v in core.items():
        w = weight_map.get(k, 0.10)
        wsum += w
        wval += w * v
    blended = (wval / wsum) if wsum > 0 else primary_val

    vals = list(core.values())
    conf = "Low"
    valuation_cv = None
    if len(vals) >= 2:
        mu = float(np.mean(vals))
        sd = float(np.std(vals))
        valuation_cv = (sd / mu) if mu > 0 else 9.0
        if valuation_cv < 0.15 and len(vals) >= 3:
            conf = "High"
        elif valuation_cv < 0.25:
            conf = "Medium-High"
        elif valuation_cv < 0.40:
            conf = "Medium"
        else:
            conf = "Low"
    elif len(vals) == 1:
        conf = "Low-Medium"

    rounded = {}
    for k, v in models.items():
        if v is None:
            continue
        rounded[k] = round(v) if v > 50 else round(v, 1)

    return {
        "models": rounded,
        "primary_name": primary_name or "N/A",
        "primary_value": round(primary_val) if primary_val and primary_val > 50 else (round(primary_val, 1) if primary_val else None),
        "blended_value": round(blended) if blended and blended > 50 else (round(blended, 1) if blended else None),
        "n_models": len(rounded),
        "valuation_confidence": conf,
        "valuation_cv": round(valuation_cv, 3) if valuation_cv is not None else None,
        "near_term_growth_used": round(near_term_g * 100, 2),
        "terminal_growth_used": round(tg * 100, 2),
    }

def run_predictive_pipeline(info, hist, fcf_history, sector, industry, fundamental_score,
                              book_value_per_share, dividend_per_share, roe_pct,
                              pat_yoy_pct, analyst_growth_pct,
                              precomputed_jpb=None, precomputed_ddm=None,
                              resolved_pe=None, is_turnaround=False, latest_quarter_net_income=None,
                              shares_outstanding=None, qualitative_bonus=0, qualitative_notes=None,
                              sector_profile="standard", order_book_hits=None, growth_pct_from_news=None):
    current_price = info.get('currentPrice')
    if not current_price and hist is not None and not hist.empty:
        current_price = float(hist['Close'].iloc[-1])

    result = {
        "verdict": "OBSERVE", "target_price": None, "entry_range": "N/A", "stop_loss": None,
        "time_horizon": "N/A", "note": None, "model_used": "N/A",
        "composite_score": None, "fundamental_score": fundamental_score,
        "intrinsic_score": None, "technical_score": None, "margin_of_safety": None,
        "discount_rate": None, "growth_used": None, "is_turnaround": is_turnaround,
    }
    if not current_price:
        return result

    notes = list(qualitative_notes or [])
    order_book_hits = order_book_hits or []
    beta = info.get('beta')
    if beta is None or pd.isna(beta) or beta <= 0:
        beta = 1.0
        
    rfr_pack = get_dynamic_risk_free_rate()
    current_rfr = _rfr_value(rfr_pack)
    rfr_source = _rfr_source(rfr_pack)
    ke_pct = min(max((current_rfr + beta * EQUITY_RISK_PREMIUM) * 100, 9), 20)
    notes.append(f"RFR source: {rfr_source} ({current_rfr * 100:.2f}%).")

    growth_pct = 8.0
    growth_source = "default (8%)"
    if analyst_growth_pct and analyst_growth_pct > 0:
        growth_pct = min(max(float(analyst_growth_pct), 5), 30)
        growth_source = f"analyst consensus ({float(analyst_growth_pct):.1f}%)"
    elif pat_yoy_pct and pat_yoy_pct > 0:
        growth_pct = min(max(pat_yoy_pct, 5), 22)
        growth_source = f"trailing PAT YoY ({pat_yoy_pct:.1f}%)"

    # Turnaround: modest lift only — do not force 20% growth automatically.
    if is_turnaround:
        prev = growth_pct
        growth_pct = min(max(growth_pct, 12.0), 22.0)
        if growth_pct > prev:
            notes.append(f"Turnaround flagged: growth assumption nudged from {prev:.0f}% to {growth_pct:.0f}% (scenario, not a hard override).")

    if order_book_hits:
        # Order wins ≠ earnings growth. Only a small additive nudge; never replace fundamentals.
        bump = 2.0
        if growth_pct_from_news:
            bump = min(float(growth_pct_from_news) * 0.25, 4.0)  # further discount soft hint
        new_growth = min(growth_pct + bump, 20)
        if new_growth > growth_pct:
            notes.append(
                f"Order-book/guidance keywords: growth nudged +{new_growth - growth_pct:.1f}pp "
                f"(to {new_growth:.1f}%). Headline order value is not mapped 1:1 to earnings."
            )
        growth_pct = new_growth

    # Near-term growth may exceed Ke; models fade toward terminal growth < Ke internally.
    # Soft cap only extreme outliers that break multi-year compounding stability.
    soft_ceiling = max(ke_pct + 8.0, 18.0)  # allow analyst-like near-term high growth
    if growth_pct > soft_ceiling:
        notes.append(
            f"Near-term growth soft-capped at {soft_ceiling:.1f}% (was {growth_pct:.1f}%); "
            f"DCF/forward models still fade to terminal g < Ke ({ke_pct:.1f}%)."
        )
        growth_pct = soft_ceiling
    elif growth_pct > ke_pct:
        notes.append(
            f"Near-term growth {growth_pct:.1f}% > Ke {ke_pct:.1f}% — allowed for explicit forecast; "
            "terminal growth remains below discount rate inside valuation models."
        )

    financial = is_financial_sector(sector, industry)
    forced_intrinsic_adjustment = 0

    shares = info.get('sharesOutstanding') or shares_outstanding
    trailing_eps = info.get('trailingEps')
    effective_eps = trailing_eps
    if is_turnaround and latest_quarter_net_income and latest_quarter_net_income > 0 and shares:
        # Annualizing one quarter is seasonal-sensitive — blend 50/50 with trailing if available
        annualized_q = (latest_quarter_net_income / shares) * 4
        if trailing_eps and trailing_eps > 0:
            effective_eps = 0.5 * float(trailing_eps) + 0.5 * annualized_q
            notes.append(
                f"Turnaround EPS: blended trailing ({float(trailing_eps):.2f}) with "
                f"annualized latest quarter ({annualized_q:.2f}) — seasonality risk remains."
            )
        else:
            effective_eps = annualized_q
            notes.append(
                f"Turnaround EPS: annualized latest quarter only ({annualized_q:.2f}) — "
                "high seasonality risk; treat as scenario input."
            )

    multi = compute_multi_model_values(
        current_price, ke_pct, growth_pct, financial, book_value_per_share, dividend_per_share,
        roe_pct, effective_eps, resolved_pe, fcf_history, shares, precomputed_jpb, precomputed_ddm,
        sector_profile, pat_yoy_pct,
    )
    # Prefer sector-weighted blend when ≥2 core models; else primary
    if multi["n_models"] >= 2 and multi.get("blended_value"):
        intrinsic_value = multi["blended_value"]
        result["model_used"] = (
            f"Weighted blend ({multi['n_models']} models; primary={multi['primary_name']}; "
            f"CV={multi.get('valuation_cv')})"
        )
    else:
        intrinsic_value = multi.get("primary_value")
        result["model_used"] = multi.get("primary_name") or "Defensive Haircut"
    if "Defensive" in str(result["model_used"]):
        forced_intrinsic_adjustment = -25
    result["valuation_models"] = multi.get("models", {})

    if not intrinsic_value or intrinsic_value <= 0:
        intrinsic_value = round(current_price * 0.75, 2) if current_price else None
        result["model_used"] = "Defensive Haircut (no reliable data)"
        forced_intrinsic_adjustment = -30

    base_value = intrinsic_value

    # True scenario revaluation: re-run models under Bear / Bull assumptions
    bear_g = max(growth_pct * 0.55, 3.0)
    bull_g = min(growth_pct * 1.35, growth_pct + 10.0)
    bear_ke = min(ke_pct + 1.5, 20.0)
    bull_ke = max(ke_pct - 1.0, 9.0)
    if current_price:
        multi_bear = compute_multi_model_values(
            current_price, bear_ke, bear_g, financial, book_value_per_share, dividend_per_share,
            roe_pct, effective_eps, resolved_pe, fcf_history, shares, None, None,
            sector_profile, pat_yoy_pct,
        )
        multi_bull = compute_multi_model_values(
            current_price, bull_ke, bull_g, financial, book_value_per_share, dividend_per_share,
            roe_pct, effective_eps, resolved_pe, fcf_history, shares, None, None,
            sector_profile, pat_yoy_pct,
        )
        bear_value = multi_bear.get("blended_value") or multi_bear.get("primary_value")
        bull_value = multi_bull.get("blended_value") or multi_bull.get("primary_value")
        # Do not force monotonic scenarios — flag inconsistency for audit
        if bear_value and base_value and bear_value > base_value:
            notes.append(
                f"Scenario inconsistency: Bear ({bear_value}) > Base ({base_value}). Review assumptions."
            )
        if bull_value and base_value and bull_value < base_value:
            notes.append(
                f"Scenario inconsistency: Bull ({bull_value}) < Base ({base_value}). Review assumptions."
            )
    else:
        bear_value = bull_value = None

    target_price = base_value
    margin_of_safety = (base_value - current_price) / current_price if current_price and base_value else 0

    atr = calculate_atr(hist)
    support = calculate_vwap_support(hist) or (current_price * 0.92)
    entry_low = round(max(support, current_price * 0.85), 2)
    entry_high = round(support + (0.5 * atr if atr else current_price * 0.02), 2)
    if entry_low > current_price:
        entry_low, entry_high = round(current_price * 0.95, 2), round(current_price, 2)
    raw_stop_loss = entry_low - (1.5 * atr if atr else entry_low * 0.05)
    stop_loss = round(max(entry_low * 0.80, raw_stop_loss), 2)

    # Multi-factor technical score (SMA / momentum / drawdown / volume / capped drift)
    tech_score, momentum, horizon, drift = compute_technical_score(hist, current_price)

    # ARIMA is confirmatory only — small nudge, never dominates
    arima_dir = None
    try:
        closes_clean = hist['Close'].dropna() if hist is not None else pd.Series(dtype=float)
        if HAS_ARIMA and len(closes_clean) > 100:
            fitted = ARIMA(closes_clean.values, order=(5, 1, 0)).fit()
            forecast = fitted.forecast(steps=20)
            arima_dir = "UP" if forecast[-1] > forecast[0] else "DOWN"
            if arima_dir == "UP" and momentum != "DOWN":
                tech_score = min(100, tech_score + 3)
            elif arima_dir == "DOWN" and momentum != "UP":
                tech_score = max(0, tech_score - 3)
            elif arima_dir != momentum and momentum in ("UP", "DOWN"):
                momentum = "MIXED"
                horizon = "3-5 Years (Mixed Signals)"
    except Exception as e:
        logger.warning("ARIMA technical step failed: %s", e)

    composite, verdict, intrinsic_score, _ = composite_verdict(
        fundamental_score, margin_of_safety, drift, arima_direction=arima_dir or momentum,
        forced_intrinsic_adjustment=forced_intrinsic_adjustment, qualitative_bonus=qualitative_bonus,
    )
    # Prefer the multi-factor tech score over the drift-only one from composite_verdict
    tech_score = round(tech_score, 1)
    # Recompute composite with multi-factor tech
    W_F, W_I, W_T = 0.42, 0.38, 0.20
    q_bonus = max(min(qualitative_bonus or 0, 5), -5)
    if fundamental_score is None:
        # Insufficient fundamental pillars — do not invent a zero and push DON'T BUY
        notes.append("Insufficient fundamental data: investment verdict capped at OBSERVE.")
        composite = round(min(max(
            W_I * intrinsic_score + W_T * tech_score + q_bonus, 0) * 0.85, 100), 1)
        if composite >= 60:
            verdict = "OBSERVE"
        elif composite >= 40:
            verdict = "OBSERVE"
        else:
            verdict = "OBSERVE"
    else:
        composite = round(min(max(
            W_F * fundamental_score + W_I * intrinsic_score + W_T * tech_score + q_bonus, 0), 100), 1)
        if composite >= 75:
            verdict = "STRONG BUY"
        elif composite >= 60:
            verdict = "BUY"
        elif composite >= 40:
            verdict = "OBSERVE"
        else:
            verdict = "DON'T BUY"

    verdict = apply_tiered_sanity_veto(verdict, target_price, current_price, notes, growth_pct=growth_pct)
    # Completeness / sector gates on assertive verdicts
    # (data_completeness is not in pipeline scope — use fundamental None + model flags)
    if verdict == "STRONG BUY" and fundamental_score is None:
        verdict = "OBSERVE"
        notes.append("STRONG BUY blocked: insufficient fundamental pillars.")
    if verdict in ("STRONG BUY", "BUY") and financial:
        notes.append(
            "Financial-sector model is screening-level only (GNPA/CRAR/CASA etc. unavailable). "
            "Do not treat as a full bank/NBFC research opinion."
        )
        if verdict == "STRONG BUY":
            verdict = "BUY"
            notes.append("STRONG BUY capped to BUY for financials without regulatory asset-quality inputs.")


    # Confidence: valuation dispersion (CV) + defensive fallback flag
    n_m = multi.get("n_models", 0)
    conf = multi.get("valuation_confidence") or "Low"
    if "Defensive Haircut" in str(result.get("model_used", "")):
        conf = "Low"

    result.update({
        "verdict": verdict, "target_price": target_price,
        "bear_value": bear_value, "base_value": base_value, "bull_value": bull_value,
        "entry_range": f"₹{entry_low:,.2f} - ₹{entry_high:,.2f}", "stop_loss": stop_loss,
        "time_horizon": horizon, "note": " ".join(notes) if notes else None,
        "composite_score": composite, "intrinsic_score": intrinsic_score, "technical_score": tech_score,
        "margin_of_safety": round(margin_of_safety * 100, 1),
        "discount_rate": round(ke_pct, 1), "growth_used": round(growth_pct, 1),
        "growth_source": growth_source, "confidence": conf, "rfr_source": rfr_source,
        "momentum": momentum,
        "valuation_models": multi.get("models", {}),
        "n_valuation_models": n_m,
        "audit": {
            "growth_source": growth_source,
            "growth_used": round(growth_pct, 1),
            "ke": round(ke_pct, 1),
            "rfr_source": rfr_source,
            "valuation_confidence": conf,
            "valuation_cv": multi.get("valuation_cv"),
            "near_term_growth": multi.get("near_term_growth_used"),
            "terminal_growth": multi.get("terminal_growth_used"),
            "model_used": result.get("model_used"),
            "fundamental_score": fundamental_score,
            "technical_score": tech_score,
            "intrinsic_score": intrinsic_score,
            "notes": notes,
        },
    })
    return result

# ============================================================
# 7. MASTER DATA FETCH
# ============================================================

# ============================================================
# FIX 3: FMP AS PRIMARY DATA SOURCE (yfinance = fallback only)
# ============================================================
@st.cache_data(ttl=1800, show_spinner=False)
def fetch_fmp_data(ticker_clean: str) -> dict:
    """Primary data fetch from Financial Modeling Prep. Returns a flat dict;
    absent keys mean FMP did not have that field — yfinance fills the gap."""
    FMP_KEY = st.secrets.get("FMP_API_KEY", "")
    if not FMP_KEY:
        return {}
    BASE = "https://financialmodelingprep.com/api/v3"
    out = {}
    headers = {"Accept": "application/json"}
    def _get(path):
        try:
            r = requests.get(f"{BASE}/{path}&apikey={FMP_KEY}", headers=headers, timeout=7)
            return r.json() if r.status_code == 200 else None
        except Exception:
            return None

    q = _get(f"quote/{ticker_clean}?")
    if q and isinstance(q, list) and q:
        out.update({k: q[0].get(v) for k, v in [
            ("currentPrice","price"),("marketCap","marketCap"),
            ("sharesOutstanding","sharesOutstanding"),("pe_ratio","pe"),
            ("eps","eps"),("fiftyTwoWeekHigh","yearHigh"),
            ("fiftyTwoWeekLow","yearLow")]})

    p = _get(f"profile/{ticker_clean}?")
    if p and isinstance(p, list) and p:
        out.update({k: p[0].get(v) for k, v in [
            ("longName","companyName"),("sector","sector"),("industry","industry"),
            ("longBusinessSummary","description"),("website","website"),("beta","beta")]})

    km = _get(f"key-metrics-ttm/{ticker_clean}?")
    if km and isinstance(km, list) and km:
        out.update({k: km[0].get(v) for k, v in [
            ("returnOnEquity","roeTTM"),("returnOnAssets","returnOnTangibleAssetsTTM"),
            ("debtToEquity","debtToEquityTTM"),("currentRatio","currentRatioTTM"),
            ("ev_ebitda","enterpriseValueOverEBITDATTM"),("priceToBook","pbRatioTTM"),
            ("dividendYieldTTM","dividendYieldTTM")]})

    inc = _get(f"income-statement/{ticker_clean}?limit=4")
    if inc and isinstance(inc, list) and len(inc) > 0:
        l = inc[0]
        out.update({k: l.get(v) for k, v in [
            ("totalRevenue","revenue"),("ebit","operatingIncome"),
            ("netIncome","netIncome"),("ebitda","ebitda"),
            ("eps","eps"),("interestExpense","interestExpense")]})
        if len(inc) >= 2 and inc[1].get("netIncome"):
            ni_now, ni_p = (l.get("netIncome") or 0), (inc[1].get("netIncome") or 1)
            out["pat_yoy"] = round(((ni_now - ni_p) / abs(ni_p)) * 100, 2)
            if len(inc) >= 3:
                ni_p2 = inc[2].get("netIncome") or 1
                out["pat_yoy_prior"] = round(((ni_p - ni_p2) / abs(ni_p2)) * 100, 2)

    bs = _get(f"balance-sheet-statement/{ticker_clean}?limit=1")
    if bs and isinstance(bs, list) and bs:
        b = bs[0]
        out.update({k: b.get(v) for k, v in [
            ("totalDebt","totalDebt"),("totalCash","cashAndCashEquivalents"),
            ("totalEquity","totalStockholdersEquity"),("totalAssets","totalAssets")]})
        if out.get("sharesOutstanding") and b.get("totalStockholdersEquity"):
            out["bookValue"] = b["totalStockholdersEquity"] / out["sharesOutstanding"]

    ae = _get(f"analyst-estimates/{ticker_clean}?limit=2")
    if ae and isinstance(ae, list) and len(ae) > 0:
        out["forwardEps"] = ae[0].get("estimatedEpsAvg")
        if len(ae) >= 2 and ae[1].get("estimatedEpsAvg") and ae[0].get("estimatedEpsAvg"):
            eps_now = ae[0]["estimatedEpsAvg"]; eps_p = ae[1]["estimatedEpsAvg"] or 1
            out["analyst_growth_pct"] = round(((eps_now - eps_p) / abs(eps_p)) * 100, 2)

    hist = _get(f"historical-price-full/{ticker_clean}?timeseries=252")
    if hist and hist.get("historical"):
        hdf = pd.DataFrame(hist["historical"])
        hdf["date"] = pd.to_datetime(hdf["date"])
        hdf = hdf.sort_values("date").rename(columns={
            "date":"Date","open":"Open","high":"High","low":"Low","close":"Close","volume":"Volume"})
        out["fmp_history"] = hdf[["Date","Open","High","Low","Close","Volume"]]
    return out


def _fmp_ticker(resolved_ticker: str) -> str:
    """Convert WELSPUNCORP.NS -> WELSPUNCORP for FMP."""
    return resolved_ticker.replace(".NS","").replace(".BO","").upper()

@st.cache_data(ttl=1800)
def fetch_stock_data(resolved_ticker, raw_input):
    # FMP primary, yfinance fallback — collect data-quality warnings for the UI
    warnings = []
    fmp = fetch_fmp_data(_fmp_ticker(resolved_ticker))
    if not fmp:
        warnings.append("FMP returned no data — relying on yfinance fallback only.")
    elif not fmp.get("currentPrice"):
        warnings.append("FMP quote incomplete — price/ratios filled from yfinance where needed.")

    stock = yf.Ticker(resolved_ticker)
    if fmp.get("fmp_history") is not None and not fmp["fmp_history"].empty:
        hist_full = fmp["fmp_history"].copy().reset_index(drop=True)
    else:
        try:
            hist_full = stock.history(period="1y")
            warnings.append("Price history from yfinance (FMP history unavailable).")
        except Exception as e:
            logger.warning("yfinance history failed for %s: %s", resolved_ticker, e)
            hist_full = pd.DataFrame()
            warnings.append(f"Price history unavailable: {e}")
    if hist_full.empty:
        raise ValueError(f"Could not find '{raw_input}'.")

    try:
        yf_info = stock.info or {}
    except Exception as e:
        logger.warning("yfinance info failed for %s: %s", resolved_ticker, e)
        yf_info = {}
        warnings.append("yfinance company info failed — some fields may be missing.")

    # Merge: FMP wins, yfinance fills gaps. Periods may mix TTM vs annual — flagged below.
    info = {**yf_info, **{k: v for k, v in fmp.items() if v is not None and k != "fmp_history"}}
    current_price = info.get("currentPrice") or round(float(hist_full['Close'].iloc[-1], 2))
    currency_symbol = "₹"
    if fmp and yf_info:
        warnings.append(
            "Metrics may mix FMP TTM fields with yfinance annual/quarterly statements — "
            "treat cross-source ratios with care."
        )

    sector = info.get("sector", "N/A")
    industry = info.get("industry", "N/A")
    is_fin = is_financial_sector(sector, industry)
    sector_profile = classify_sector_profile(sector, industry)
    revenue_keys = BANK_REVENUE_KEYS if is_fin else STANDARD_REVENUE_KEYS
    if is_fin:
        warnings.append(
            "Financial-sector coverage is incomplete: GNPA/NNPA, CRAR/CET1, PCR, CASA, "
            "credit cost and slippage are not available from current free data sources. "
            "Bank/NBFC scores should be treated as screening-only."
        )

    pnl_df, bs_df, cf_df = pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    net_inc, total_eq, total_assets_latest, ebitda_val = None, None, None, info.get('ebitda')
    revenue_latest, ebit_latest, interest_exp_latest, interest_income_latest = None, None, None, None
    fcf_history = None
    pat_qoq, pat_yoy_pct, net_margin_final = None, None, None
    latest_quarter_net_income = None
    revenue_cagr_pct = None

    try:
        q_fin = stock.quarterly_financials
        if q_fin is not None and not q_fin.empty and 'Net Income' in q_fin.index:
            ni_series = q_fin.loc['Net Income'].dropna()
            if len(ni_series) > 0:
                net_inc = float(ni_series.iloc[:4].sum())
                latest_quarter_net_income = float(ni_series.iloc[0])
            if len(ni_series) >= 2 and ni_series.iloc[1] != 0:
                pat_qoq = round(((ni_series.iloc[0] - ni_series.iloc[1]) / abs(ni_series.iloc[1])) * 100, 2)
            if len(ni_series) >= 5 and ni_series.iloc[4] != 0:
                pat_yoy_pct = round(((ni_series.iloc[0] - ni_series.iloc[4]) / abs(ni_series.iloc[4])) * 100, 2)
            rev_key_found = next((k for k in revenue_keys if k in q_fin.index), None)
            if rev_key_found and len(ni_series) > 0:
                rev_series = q_fin.loc[rev_key_found].dropna()
                if len(rev_series) > 0 and rev_series.iloc[0] != 0:
                    net_margin_final = round((ni_series.iloc[0] / rev_series.iloc[0]) * 100, 2)

        fin = stock.financials
        if fin is not None and not fin.empty:
            rev_key_found = next((k for k in revenue_keys if k in fin.index), None)
            if rev_key_found and pd.notna(fin.loc[rev_key_found].iloc[0]):
                revenue_latest = float(fin.loc[rev_key_found].iloc[0])
                rev_series_annual = fin.loc[rev_key_found].dropna()
                if len(rev_series_annual) >= 2 and rev_series_annual.iloc[-1] > 0:
                    years = len(rev_series_annual) - 1
                    revenue_cagr_pct = round((((rev_series_annual.iloc[0] / rev_series_annual.iloc[-1]) ** (1 / years)) - 1) * 100, 2)
            for k in ['EBIT', 'Operating Income']:
                if k in fin.index and pd.notna(fin.loc[k].iloc[0]):
                    ebit_latest = float(fin.loc[k].iloc[0]); break
            if 'Interest Expense' in fin.index:
                ie_series = fin.loc['Interest Expense'].dropna()
                if len(ie_series) > 0:
                    interest_exp_latest = float(ie_series.iloc[0])
            ii_key_found = next((k for k in INTEREST_INCOME_KEYS if k in fin.index), None)
            if ii_key_found:
                ii_series = fin.loc[ii_key_found].dropna()
                if len(ii_series) > 0:
                    interest_income_latest = float(ii_series.iloc[0])

        bs = stock.balance_sheet
        if bs is not None and not bs.empty:
            for k in ['Stockholders Equity', 'Total Stockholder Equity', 'Common Stock Equity']:
                if k in bs.index:
                    eq_series = bs.loc[k].dropna()
                    if len(eq_series) > 0:
                        total_eq = float(eq_series.iloc[0]); break
            if 'Total Assets' in bs.index:
                ta_series = bs.loc['Total Assets'].dropna()
                if len(ta_series) > 0:
                    total_assets_latest = float(ta_series.iloc[0])

        cf = stock.cashflow
        if cf is not None and not cf.empty and 'Free Cash Flow' in cf.index:
            # Dropna and reverse to ensure chronological or at least clean iteration
            fcf_history = cf.loc['Free Cash Flow'].dropna()

        if fin is not None and not fin.empty:
            col = fin.columns[0]
            rev_key_found = next((k for k in revenue_keys if k in fin.index), None)
            pnl_df = pd.DataFrame([
                {"Particulars": "Net Sales / Total Income", "Amount (₹ Cr)": round(fin.loc[rev_key_found, col] / 10000000, 2) if rev_key_found else "—"},
                {"Particulars": "Operating Profit", "Amount (₹ Cr)": round(fin.loc['Operating Income', col] / 10000000, 2) if 'Operating Income' in fin.index else "—"},
                {"Particulars": "Net Profit", "Amount (₹ Cr)": round(fin.loc['Net Income', col] / 10000000, 2) if 'Net Income' in fin.index else "—"}
            ])
        if bs is not None and not bs.empty:
            col = bs.columns[0]
            bs_df = pd.DataFrame([
                {"Particulars": "Total Equity", "Amount (₹ Cr)": round(total_eq / 10000000, 2) if total_eq else "—"},
                {"Particulars": "Total Debt", "Amount (₹ Cr)": round(bs.loc['Total Debt', col] / 10000000, 2) if 'Total Debt' in bs.index else "—"},
                {"Particulars": "Total Assets", "Amount (₹ Cr)": round(bs.loc['Total Assets', col] / 10000000, 2) if 'Total Assets' in bs.index else "—"}
            ])
        if cf is not None and not cf.empty:
            col = cf.columns[0]
            cf_df = pd.DataFrame([
                {"Particulars": "Operating Cash Flow", "Amount (₹ Cr)": round(cf.loc['Operating Cash Flow', col] / 10000000, 2) if 'Operating Cash Flow' in cf.index else "—"},
                {"Particulars": "Free Cash Flow", "Amount (₹ Cr)": round(cf.loc['Free Cash Flow', col] / 10000000, 2) if 'Free Cash Flow' in cf.index else "—"}
            ])
    except Exception as e:
        logger.warning("Financial statement parse failed for %s: %s", resolved_ticker, e)
        warnings.append(f"Statement parse issue: {e}")

    shares_out = info.get("sharesOutstanding")
    mcap = info.get("marketCap")
    
    # --- FIX: Indian Market Cap / Shares Sanity Check ---
    if mcap and shares_out and current_price:
        calculated_mcap = shares_out * current_price
        if abs(calculated_mcap - mcap) / mcap > 0.15:
            mcap = calculated_mcap
    elif current_price and shares_out:
        mcap = current_price * shares_out

    operating_margin = round((ebit_latest / revenue_latest) * 100, 2) if (ebit_latest is not None and revenue_latest) else None

    nim_proxy = None
    if is_fin and interest_income_latest is not None and interest_exp_latest is not None and total_assets_latest:
        nim_proxy = round(((interest_income_latest - interest_exp_latest) / total_assets_latest) * 100, 2)

    trailing_earnings_negative = (net_inc is not None and net_inc < 0) or (info.get('trailingEps') and info.get('trailingEps') < 0)
    
    # --- FIX: Turnaround strictly needs positive operating profit ---
    is_turnaround = bool(trailing_earnings_negative and (
        (pat_qoq is not None and pat_qoq > 50) or 
        (latest_quarter_net_income is not None and latest_quarter_net_income > 0 and ebit_latest is not None and ebit_latest > 0)
    ))

    recent_news = fetch_google_news(f"{info.get('longName', resolved_ticker)} stock news")
    business_summary = info.get("longBusinessSummary")
    qualitative_bonus, qualitative_notes = scan_news_sentiment(recent_news, business_summary)
    order_book_hits, growth_pct_from_news = extract_order_book_signal(recent_news, business_summary)

    pe_raw = info.get("trailingPE")
    if not is_valid_metric(pe_raw) and net_inc and mcap:
        pe_raw = round(mcap / net_inc, 2)
    elif is_valid_metric(pe_raw):
        pe_raw = round(float(pe_raw), 2)

    pb_raw = info.get("priceToBook")
    if not is_valid_metric(pb_raw) and total_eq and mcap and total_eq > 0:
        pb_raw = round(mcap / total_eq, 2)
    elif is_valid_metric(pb_raw):
        pb_raw = round(float(pb_raw), 2)

    roe_raw = info.get("returnOnEquity")
    if not is_valid_metric(roe_raw) and net_inc and total_eq and total_eq > 0:
        roe_raw = net_inc / total_eq
    roe_is_known = is_valid_metric(roe_raw)

    peg_raw = info.get("pegRatio")
    if not is_valid_metric(peg_raw) and is_valid_metric(pe_raw) and pat_yoy_pct and pat_yoy_pct > 0:
        peg_raw = round(to_float(pe_raw) / pat_yoy_pct, 2)
    elif is_valid_metric(peg_raw):
        peg_raw = round(float(peg_raw), 2)

    ev_ebitda = "N/A"
    if is_fin:
        ev_ebitda = "N/A (Financial Sector)"
    else:
        ev_val = info.get("enterpriseValue")
        if not is_valid_metric(ev_val) and mcap:
            ev_val = mcap + (info.get('totalDebt') or 0) - (info.get('totalCash') or 0)
        if is_valid_metric(ebitda_val) and is_valid_metric(ev_val) and ebitda_val != 0:
            ev_ebitda = round(ev_val / ebitda_val, 2)
        elif is_valid_metric(ev_ebitda):
            ev_ebitda = round(float(ev_ebitda), 2)

    ebitda_margin = round((ebitda_val / revenue_latest) * 100, 2) if (is_valid_metric(ebitda_val) and revenue_latest) else "N/A"
    interest_coverage = round(ebit_latest / interest_exp_latest, 2) if (ebit_latest is not None and interest_exp_latest) else "N/A"
    dte_raw = info.get("debtToEquity")
    # yfinance often stores D/E as percent (e.g. 80 for 0.80); FMP may already be ratio
    if is_valid_metric(dte_raw):
        dte_num = float(dte_raw)
        # yfinance debtToEquity is typically percent (e.g. 85.3). True ratio >10 is rare
        # but possible for distressed firms — prefer source-aware rule when schema known.
        # Heuristic: values in (5, 30] could be either; treat >15 as percent (common yf range).
        if dte_num > 15:
            debt_to_equity = round(dte_num / 100.0, 2)
        else:
            debt_to_equity = round(dte_num, 2)
    else:
        debt_to_equity = "N/A"

    temp_metrics = {
        'pe_ratio': pe_raw, 'peg_ratio': peg_raw, 'pb_ratio': pb_raw,
        'pat_yoy': pat_yoy_pct, 'roe': (roe_raw * 100) if roe_is_known else None,
        'ev_ebitda': ev_ebitda, 'is_financial_sector': is_fin, 'debt_to_equity': debt_to_equity,
        'interest_coverage': interest_coverage, 'net_margin': net_margin_final, 'pat_qoq': pat_qoq,
        'operating_margin': operating_margin, 'revenue_cagr': revenue_cagr_pct,
        'sector_profile': sector_profile, 'nim_proxy': nim_proxy,
    }
    # Binary checklists kept for transparent UI; continuous scores drive the model
    v_bin, v_avail, v_poss = score_from_checks(valuation_checks(temp_metrics))
    p_bin, p_avail, p_poss = score_from_checks(past_performance_checks(temp_metrics))
    h_bin, h_avail, h_poss = score_from_checks(financial_health_checks(temp_metrics))
    v_score = continuous_valuation_score(temp_metrics)
    p_score = continuous_past_score(temp_metrics)
    h_score = continuous_health_score(temp_metrics)
    # Fall back to binary if continuous has nothing
    if v_score is None:
        v_score = v_bin
    if p_score is None:
        p_score = p_bin
    if h_score is None:
        h_score = h_bin
    fundamental_score, data_completeness = compute_fundamental_score(
        v_score, p_score, h_score, is_fin,
        v_avail, p_avail, h_avail, v_poss, p_poss, h_poss
    )
    # Turnaround: single centralized note — growth nudge only inside pipeline (no double bonus)
    if is_turnaround and fundamental_score is not None:
        pass  # do not add a second fundamental bonus

    bvps = info.get('bookValue')
    if not is_valid_metric(bvps) and total_eq and shares_out:
        bvps = total_eq / shares_out
    bvps = bvps if is_valid_metric(bvps) else None
    div_per_share = info.get("dividendRate")

    jpb_ratio = jpb_value = ddm_val = None
    if is_fin:
        beta_preview = info.get('beta') if info.get('beta') and pd.notna(info.get('beta')) and info.get('beta') > 0 else 1.0
        current_rfr = _rfr_value(get_dynamic_risk_free_rate())
        ke_preview = min(max((current_rfr + beta_preview * EQUITY_RISK_PREMIUM) * 100, 9), 20)
        analyst_growth_pct_pre = None
        if isinstance(fmp, dict):
            analyst_growth_pct_pre = fmp.get("analyst_growth_pct")
        if analyst_growth_pct_pre is None:
            analyst_growth_pct_pre = info.get("analyst_growth_pct")
        if analyst_growth_pct_pre and float(analyst_growth_pct_pre) > 0:
            growth_preview = min(max(float(analyst_growth_pct_pre), 5), 30)
        elif pat_yoy_pct and pat_yoy_pct > 0:
            growth_preview = pat_yoy_pct
        else:
            growth_preview = 8.0
        jpb_ratio, jpb_value = justified_pb_fair_value(roe_raw * 100 if roe_is_known else None, ke_preview, growth_preview, bvps)
        ddm_val = ddm_fair_value(div_per_share, ke_preview, growth_preview)
    temp_metrics["justified_pb"] = jpb_ratio

    analyst_growth_pct = fmp.get("analyst_growth_pct") if isinstance(fmp, dict) else None
    if analyst_growth_pct is None:
        analyst_growth_pct = info.get("analyst_growth_pct")

    predictive_data = run_predictive_pipeline(
        info, hist_full, fcf_history, sector, industry, fundamental_score,
        bvps, div_per_share, roe_raw * 100 if roe_is_known else None, pat_yoy_pct, analyst_growth_pct,
        precomputed_jpb=(jpb_ratio, jpb_value), precomputed_ddm=ddm_val,
        resolved_pe=to_float(pe_raw), is_turnaround=is_turnaround,
        latest_quarter_net_income=latest_quarter_net_income, shares_outstanding=shares_out,
        qualitative_bonus=qualitative_bonus, qualitative_notes=qualitative_notes,
        sector_profile=sector_profile, order_book_hits=order_book_hits, growth_pct_from_news=growth_pct_from_news,
    )

    promoters = (info.get("heldPercentInsiders") or 0) * 100
    institutions = (info.get("heldPercentInstitutions") or 0) * 100
    if promoters == 0 and institutions == 0:
        shareholding_dict = {"Data Unavailable": 100}
    else:
        shareholding_dict = {
            "Promoters": promoters,
            "Institutions": institutions,
            "Public": max(0, 100 - (promoters + institutions))
        }

    try:
        mf_df = stock.mutualfund_holders
    except Exception as e:
        logger.warning("Mutual fund holders unavailable for %s: %s", resolved_ticker, e)
        mf_df = None
        
    try:
        cal = stock.calendar
        if isinstance(cal, dict):
            cal_df = pd.DataFrame(list(cal.items()), columns=['Event', 'Date'])
        else:
            cal_df = cal
    except Exception as e:
        logger.warning("Calendar unavailable for %s: %s", resolved_ticker, e)
        cal_df = None

    metrics = {
        "name": info.get("longName", resolved_ticker), "price": current_price,
        "pe_ratio": pe_raw if is_valid_metric(pe_raw) else "N/A",
        "pb_ratio": pb_raw if is_valid_metric(pb_raw) else "N/A",
        "peg_ratio": peg_raw if is_valid_metric(peg_raw) else "N/A",
        "ev_ebitda": ev_ebitda if is_valid_metric(ev_ebitda) else ev_ebitda,
        "roe": f"{round(roe_raw*100, 2)}%" if roe_is_known else "N/A",
        "ebitda_margin": f"{ebitda_margin}%" if ebitda_margin != "N/A" else "N/A",
        "operating_margin": operating_margin, "revenue_cagr": revenue_cagr_pct, "nim_proxy": nim_proxy,
        "debt_to_equity": debt_to_equity,
        "interest_coverage": interest_coverage,
        "net_margin": f"{net_margin_final}%" if net_margin_final is not None else "N/A",
        "dividend_yield": f"{round(info.get('dividendYield',0)*100,2)}%" if is_valid_metric(info.get('dividendYield')) else "N/A",
        "pat_yoy": f"{pat_yoy_pct}%" if pat_yoy_pct is not None else "N/A",
        "pat_qoq": f"{pat_qoq}%" if pat_qoq is not None else "N/A",
        "market_cap": mcap, "sector": sector, "industry": industry,
        "is_financial_sector": is_fin, "justified_pb": jpb_ratio, "is_turnaround": is_turnaround,
        "sector_profile": sector_profile, "order_book_hits": order_book_hits,
        "growth_pct_from_news": growth_pct_from_news,
        "data_completeness": data_completeness,
        "rfr_source": predictive_data.get("rfr_source"),
        "audit": predictive_data.get("audit"),
        "data_warnings": warnings,
        "warnings": warnings,
        "v_score": v_score, "q_score": p_score, "f_score": h_score,
        "valuation_checks": valuation_checks(temp_metrics),
        "past_checks": past_performance_checks(temp_metrics),
        "health_checks": financial_health_checks(temp_metrics),
        "metric_provenance": {
            "pe_ratio": make_metric(pe_raw if is_valid_metric(pe_raw) else None,
                                    source="FMP" if fmp.get("pe_ratio") else "yfinance/derived",
                                    period="TTM", confidence=0.8 if is_valid_metric(pe_raw) else 0.3),
            "pb_ratio": make_metric(pb_raw if is_valid_metric(pb_raw) else None,
                                    source="FMP" if fmp.get("priceToBook") else "yfinance/derived",
                                    period="TTM", confidence=0.8 if is_valid_metric(pb_raw) else 0.3),
            "roe": make_metric((roe_raw * 100) if roe_is_known else None,
                               source="FMP/yfinance", period="TTM", confidence=0.75 if roe_is_known else 0.2),
            "pat_yoy": make_metric(pat_yoy_pct, source="quarterly_financials", period="YoY quarter",
                                   confidence=0.7 if pat_yoy_pct is not None else 0.2),
        },
        "fifty_two_high": info.get("fiftyTwoWeekHigh", "N/A"),
        "fifty_two_low": info.get("fiftyTwoWeekLow", "N/A"),
        "business_summary": business_summary,
        "website": info.get("website", "N/A"),
        "company_officers": info.get("companyOfficers", []),
        "recent_news": recent_news,
        "shareholding": shareholding_dict,
        "mutual_funds": mf_df,
        "calendar": cal_df,
        "target_mean_price": info.get("targetMeanPrice"),
        "recommendation_mean": info.get("recommendationMean"),
        "v_score": v_score,
        "p_score": p_score,
        "h_score": h_score,
        "working_ticker": resolved_ticker, "history": hist_full.reset_index(),
        "pnl_df": pnl_df, "bs_df": bs_df, "cf_df": cf_df,
        "predictive": predictive_data, "fair_value": predictive_data['target_price'],
        "currency": currency_symbol, "fundamental_score": fundamental_score,
    }

    # --- SECTOR ALTERNATIVE SCANNER — FMP PRIMARY, yfinance FALLBACK ---
    metrics['best_alternative'] = None
    if predictive_data['verdict'] in ["DON'T BUY", "OBSERVE"]:
        peers = SECTOR_PEERS.get(sector_profile, SECTOR_PEERS["standard"])
        best_peer = None

        for peer in peers:
            if peer == resolved_ticker:
                continue
            try:
                # PRIMARY: FMP data for the peer ticker
                p_fmp = fetch_fmp_data(_fmp_ticker(peer))

                # Merge FMP with yfinance fallback for any missing fields
                p_yf_info = {}
                p_hist = pd.DataFrame()
                if not p_fmp or p_fmp.get("currentPrice") is None:
                    try:
                        p_stock = yf.Ticker(peer)
                        p_yf_info = p_stock.info
                        p_hist = p_stock.history(period="1y")
                    except Exception:
                        pass
                else:
                    # FMP has data — only fetch yfinance history if FMP history missing
                    if p_fmp.get("fmp_history") is not None and not p_fmp["fmp_history"].empty:
                        p_hist = p_fmp["fmp_history"]
                    else:
                        try:
                            p_hist = yf.Ticker(peer).history(period="1y")
                        except Exception:
                            pass

                if p_hist is None or (hasattr(p_hist, 'empty') and p_hist.empty):
                    continue

                # Merge: FMP wins, yfinance fills gaps
                p_info = {**p_yf_info, **{k: v for k, v in p_fmp.items()
                                            if v is not None and k != "fmp_history"}}

                # Resolve price
                p_current_price = (p_info.get("currentPrice") or
                                    p_info.get("price") or
                                    float(p_hist['Close'].iloc[-1]))

                p_sector   = p_info.get("sector", "N/A")
                p_industry = p_info.get("industry", "N/A")
                p_is_fin   = is_financial_sector(p_sector, p_industry)

                # Ratios — FMP fields take priority (already merged into p_info)
                p_pe  = p_info.get("pe_ratio") or p_info.get("trailingPE")
                p_pb  = p_info.get("priceToBook")
                p_roe = p_info.get("returnOnEquity")
                p_dte = p_info.get("debtToEquity")

                pe_val  = float(p_pe) if p_pe and float(p_pe) > 0 else 999
                # FMP returns ROE as a ratio (0.18) when from key-metrics-ttm
                roe_raw = float(p_roe) if p_roe and pd.notna(p_roe) else 0
                roe_val = roe_raw * 100 if roe_raw < 5 else roe_raw   # normalise fraction→%
                dte_raw = float(p_dte) if p_dte and pd.notna(p_dte) else 999
                dte_val = (dte_raw / 100.0) if dte_raw > 15 else dte_raw  # yf percent vs ratio

                closes = p_hist['Close'].dropna()
                is_uptrend = (closes.iloc[-1] > closes.rolling(50).mean().iloc[-1]
                               if len(closes) > 50 else True)

                qualifies = (0 < pe_val < 30 and
                              roe_val > 15 and
                              dte_val < (2.0 if p_is_fin else 0.8) and
                              is_uptrend)

                if qualifies:
                    # Economically meaningful relative score: high ROE / reasonable PE
                    # (avoid the nonsensical ROE - PE arithmetic)
                    earnings_yield = (100.0 / pe_val) if pe_val > 0 else 0
                    score = (0.55 * min(roe_val, 40) / 40.0 * 100) + (0.45 * min(earnings_yield, 12) / 12.0 * 100)
                    candidate = {
                        "name": p_info.get("longName") or p_info.get("shortName") or peer,
                        "ticker": peer,
                        "price": p_current_price,
                        "pe":    round(pe_val, 1),
                        "pb":    round(float(p_pb), 1) if p_pb and pd.notna(p_pb) else "N/A",
                        "_score": score,
                        "source": "FMP" if p_fmp.get("currentPrice") else "yfinance",
                    }
                    if best_peer is None or score > best_peer.get("_score", -999):
                        best_peer = candidate

            except Exception as e:
                logger.warning("Peer scan failed for %s: %s", peer, e)
                continue

        metrics['best_alternative'] = best_peer

    return metrics

# ============================================================
# 8. UI PLOTLY CHARTS & NEW ANGEL ONE COMPONENTS
# ============================================================
def price_history_chart(hist_df, currency):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=hist_df['Date'], y=hist_df['Close'], mode='lines', line=dict(color=BLUE, width=1.5), fill='tozeroy', fillcolor='rgba(56,189,248,0.08)'))
    fig.update_layout(template='plotly_dark', paper_bgcolor=BG, plot_bgcolor=BG, height=260, margin=dict(t=20, b=20, l=10, r=10), xaxis=dict(showgrid=False), yaxis=dict(showgrid=False, title=currency))
    return fig

def fair_value_bar(price, fv, currency):
    fig = go.Figure()
    fig.add_trace(go.Bar(x=['Current Price'], y=[price], marker_color=BLUE, text=[f"{currency}{price:,.2f}"], textposition='auto'))
    fig.add_trace(go.Bar(x=['Modeled Fair Value'], y=[fv], marker_color=GREEN, text=[f"{currency}{fv:,.2f}"], textposition='auto'))
    diff_pct = round(((price - fv) / fv) * 100, 1) if fv else None
    fig.update_layout(template='plotly_dark', paper_bgcolor=BG, plot_bgcolor=BG, height=320, margin=dict(t=20, b=20, l=10, r=10), showlegend=False, yaxis=dict(showgrid=False))
    return fig, diff_pct

def projection_path_chart(hist_df, target_price):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=hist_df['Date'], y=hist_df['Close'], mode='lines', line=dict(color=BLUE, width=2), name='Historical Price'))
    last_date, last_price = hist_df['Date'].iloc[-1], hist_df['Close'].iloc[-1]
    fig.add_trace(go.Scatter(x=[last_date, last_date + timedelta(days=365)], y=[last_price, target_price], mode='lines', line=dict(color=GOLD, width=2, dash='dot'), name='Illustrative Target'))
    fig.update_layout(template='plotly_dark', paper_bgcolor=BG, plot_bgcolor=BG, height=300, margin=dict(t=20, b=20, l=10, r=10), legend=dict(orientation="h", y=-0.2))
    return fig

def analysis_radar_chart(m, pred):
    categories = ['Fundamentals', 'Valuation', 'Momentum']
    values = [m.get('fundamental_score', 50), pred.get('intrinsic_score', 50), pred.get('technical_score', 50)]
    fig = go.Figure()
    fig.add_trace(go.Scatterpolar(r=values + [values[0]], theta=categories + [categories[0]], fill='toself', fillcolor='rgba(234,179,8,0.35)', line=dict(color=GOLD, width=2)))
    fig.update_layout(polar=dict(bgcolor=BG, radialaxis=dict(visible=False, range=[0, 100]), angularaxis=dict(color=MUTED, gridcolor=BORDER)), showlegend=False, paper_bgcolor=BG, margin=dict(t=10, b=10, l=30, r=30), height=230)
    return fig

def ownership_donut(shareholding):
    colors = [BLUE, PURPLE, GOLD] if "Data Unavailable" not in shareholding else [MUTED]
    fig = go.Figure(data=[go.Pie(labels=list(shareholding.keys()), values=list(shareholding.values()), hole=.5, marker_colors=colors)])
    fig.update_layout(template='plotly_dark', paper_bgcolor=BG, plot_bgcolor=BG, height=240, margin=dict(t=10, b=10, l=10, r=10), legend=dict(orientation="h", y=-0.1))
    return fig

# --- ANGEL ONE COMPONENT: 52-WEEK RANGE BAR ---
def render_52week_range(current_price, low_52, high_52, currency="₹"):
    if current_price is None or low_52 is None or high_52 is None or high_52 <= low_52: return
    pct_position = ((current_price - low_52) / (high_52 - low_52)) * 100
    fig = go.Figure()
    fig.add_trace(go.Bar(x=[100], y=["Range"], orientation="h", marker=dict(color="#1F1F1F"), hoverinfo="none"))
    fig.add_trace(go.Scatter(x=[pct_position], y=["Range"], mode="markers", marker=dict(color="#38BDF8", size=16, symbol="diamond"), name="Current Price"))
    fig.update_layout(height=50, margin=dict(l=10, r=10, t=10, b=10), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[0, 100]), yaxis=dict(showgrid=False, zeroline=False, showticklabels=False), showlegend=False)
    st.markdown(f"<div style='color:{MUTED}; font-size:0.85em; text-align:center;'><b>52W Low:</b> {currency}{low_52:,.2f} &nbsp;&nbsp;|&nbsp;&nbsp; <b>Current:</b> <span style='color:#E6E6E6;'>{currency}{current_price:,.2f}</span> &nbsp;&nbsp;|&nbsp;&nbsp; <b>52W High:</b> {currency}{high_52:,.2f}</div>", unsafe_allow_html=True)
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

# --- ANGEL ONE COMPONENT: SMART SUMMARY CARDS ---
def render_price_summary_cards(df, current_price, low_52, high_52):
    if df is None or df.empty or current_price is None: return
    sma_20 = df["Close"].rolling(20).mean().iloc[-1]
    sma_50 = df["Close"].rolling(50).mean().iloc[-1]
    sma_200 = df["Close"].rolling(200).mean().iloc[-1]

    c1, c2, c3 = st.columns(3)
    if low_52 and high_52:
        dist_from_low = ((current_price - low_52) / low_52) * 100
        with c1:
            if dist_from_low <= 5:
                st.info(f"📍 **Near 52W Low:** Just {dist_from_low:.1f}% above 52-week low.")
            else:
                st.info(f"📊 **52W Position:** {((current_price - low_52) / (high_52 - low_52)) * 100:.1f}% of 52-week range.")
    with c2:
        if pd.notna(sma_50) and pd.notna(sma_200):
            if current_price > sma_50 and current_price > sma_200:
                st.success("📈 **Bullish Trend:** Trading above 50-day & 200-day SMAs.")
            elif current_price < sma_50 and current_price < sma_200:
                st.error("📉 **Bearish Trend:** Trading below 50-day & 200-day SMAs.")
            else:
                st.warning("⚖️ **Mixed Trend:** Trading between 50-day & 200-day SMAs.")
    with c3:
        if "Volume" in df.columns and len(df) >= 6:
            vol_today = df["Volume"].iloc[-1]
            vol_avg_5d = df["Volume"].iloc[-6:-1].mean()
            vol_ratio = (vol_today / vol_avg_5d) if vol_avg_5d > 0 else 1.0
            if vol_ratio > 1.5:
                st.success(f"🔥 **High Volume:** Today's volume is {vol_ratio:.1f}x higher than 5-day avg.")
            else:
                st.info(f"💧 **Normal Volume:** Trading volume is steady ({vol_ratio:.1f}x 5-day avg).")

# --- ANGEL ONE COMPONENT: SCORECARD BADGES ---
def render_scorecard_badges(q_score, v_score, f_score):
    def get_badge(score, is_val=False):
        if score is None: return "N/A", "N/A", MUTED
        rating = max(1, min(5, round((score / 100) * 5)))
        if is_val:
            lbl = "VERY CHEAP" if rating==5 else "ATTRACTIVE" if rating==4 else "FAIR" if rating==3 else "EXPENSIVE" if rating==2 else "VERY EXPENSIVE"
        else:
            lbl = "EXCELLENT" if rating==5 else "GOOD" if rating==4 else "AVERAGE" if rating==3 else "WEAK" if rating==2 else "POOR"
        clr = GREEN if rating >= 4 else GOLD if rating == 3 else RED
        return rating, lbl, clr

    q_rat, q_lbl, q_clr = get_badge(q_score)
    v_rat, v_lbl, v_clr = get_badge(v_score, is_val=True)
    f_rat, f_lbl, f_clr = get_badge(f_score)

    st.markdown(f"""
    <div style="display: flex; gap: 15px; margin-bottom: 20px;">
        <div style="background:{CARD_BG}; border:1px solid {BORDER}; border-radius:8px; padding:12px 18px; flex:1;">
            <div style="color:{MUTED}; font-size:0.8em; font-weight:600; text-transform:uppercase;">Quality</div>
            <div style="margin-top:5px; display:flex; align-items:center; gap:10px;">
                <span style="color:{q_clr}; border:1px solid {q_clr}; padding:2px 8px; border-radius:4px; font-weight:700; font-size:0.85em;">{q_lbl}</span>
                <span style="color:#E6E6E6; font-weight:700; font-size:1em;">{q_rat}/5</span>
            </div>
        </div>
        <div style="background:{CARD_BG}; border:1px solid {BORDER}; border-radius:8px; padding:12px 18px; flex:1;">
            <div style="color:{MUTED}; font-size:0.8em; font-weight:600; text-transform:uppercase;">Valuation</div>
            <div style="margin-top:5px; display:flex; align-items:center; gap:10px;">
                <span style="color:{v_clr}; border:1px solid {v_clr}; padding:2px 8px; border-radius:4px; font-weight:700; font-size:0.85em;">{v_lbl}</span>
                <span style="color:#E6E6E6; font-weight:700; font-size:1em;">{v_rat}/5</span>
            </div>
        </div>
        <div style="background:{CARD_BG}; border:1px solid {BORDER}; border-radius:8px; padding:12px 18px; flex:1;">
            <div style="color:{MUTED}; font-size:0.8em; font-weight:600; text-transform:uppercase;">Financial Health</div>
            <div style="margin-top:5px; display:flex; align-items:center; gap:10px;">
                <span style="color:{f_clr}; border:1px solid {f_clr}; padding:2px 8px; border-radius:4px; font-weight:700; font-size:0.85em;">{f_lbl}</span>
                <span style="color:#E6E6E6; font-weight:700; font-size:1em;">{f_rat}/5</span>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

# --- ANGEL ONE COMPONENT: VALUATION SPECTRUM ---
def render_valuation_spectrum(current_price, fair_value, currency="₹"):
    if not fair_value or not current_price: return
    attractive_limit = round(fair_value * 0.85, 2)
    expensive_limit = round(fair_value * 1.50, 2)
    high_limit = round(fair_value * 2.50, 2)

    if current_price <= attractive_limit: pos = 15
    elif current_price >= high_limit: pos = 90
    else: pos = 15 + ((current_price - attractive_limit) / (high_limit - attractive_limit)) * 75

    fig = go.Figure()
    fig.add_trace(go.Bar(x=[100], y=["Valuation"], orientation="h", marker=dict(color=[pos], colorscale=[[0.0, GREEN], [0.4, GOLD], [1.0, RED]], showscale=False), hoverinfo="none"))
    fig.add_trace(go.Scatter(x=[pos], y=["Valuation"], mode="markers", marker=dict(color="#FFFFFF", size=18, symbol="triangle-up"), name="Current Price"))
    fig.update_layout(height=80, margin=dict(l=10, r=10, t=10, b=10), paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", xaxis=dict(showgrid=False, zeroline=False, showticklabels=False, range=[0, 100]), yaxis=dict(showgrid=False, zeroline=False, showticklabels=False), showlegend=False)

    st.markdown(f"##### Valuation Zone — Current Price: **{currency}{current_price:,.2f}**")
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})
    
    col1, col2, col3 = st.columns([1, 1, 1])
    with col1: st.markdown(f"<div style='color:{GREEN}; font-size:0.85em;'><b>Attractive:</b> Below {currency}{attractive_limit:,.2f}</div>", unsafe_allow_html=True)
    with col2: st.markdown(f"<div style='color:{GOLD}; font-size:0.85em; text-align:center;'><b>Fair/Exp:</b> {currency}{attractive_limit:,.2f} – {currency}{expensive_limit:,.2f}</div>", unsafe_allow_html=True)
    with col3: st.markdown(f"<div style='color:{RED}; font-size:0.85em; text-align:right;'><b>High:</b> Above {currency}{high_limit:,.2f}</div>", unsafe_allow_html=True)

# --- ANGEL ONE COMPONENT: ANALYST CONSENSUS ---
def render_analyst_consensus(target, current, rec, currency="₹"):
    if not target or not current: return
    upside = ((target - current) / current) * 100
    color = GREEN if upside > 0 else RED
    st.markdown(f"""
    <div style='background:{CARD_BG}; border:1px solid {BORDER}; border-radius:8px; padding:15px; margin-top:15px;'>
        <div style='color:{MUTED}; font-size:0.85em; font-weight:600; text-transform:uppercase;'>Analyst Consensus Target</div>
        <div style='display:flex; justify-content:space-between; align-items:flex-end; margin-top:8px;'>
            <div style='font-size:1.8em; font-weight:800;'>{currency}{target:,.2f}</div>
            <div style='color:{color}; font-weight:700; font-size:1.1em;'>{'+' if upside>0 else ''}{upside:.2f}% Expected</div>
        </div>
        <div style='color:{MUTED}; font-size:0.8em; margin-top:4px;'>Recommendation Mean: {rec or 'N/A'} (1=Strong Buy, 5=Sell)</div>
    </div>
    """, unsafe_allow_html=True)

# --- ANGEL ONE COMPONENT: HIGHLIGHTS CARD ---
def extract_highlights(metrics, cf_df):
    working, not_working = [], []
    if cf_df is not None and not cf_df.empty and "Operating Cash Flow" in cf_df.index:
        ocf_series = cf_df.loc["Operating Cash Flow"].dropna()
        if len(ocf_series) > 0 and ocf_series.iloc[0] == ocf_series.max() and ocf_series.iloc[0] > 0:
            working.append(f"Operating Cash Flow (Yearly) — Highest at ₹{round(ocf_series.iloc[0] / 10000000, 2):,.2f} Cr")
    
    ic = metrics.get('interest_coverage')
    if is_valid_metric(ic):
        if float(ic) > 10: working.append(f"Operating Profit to Interest — Strong coverage at {float(ic):.2f}x")
        elif float(ic) < 2.5: not_working.append(f"Interest Coverage — Low buffer at {float(ic):.2f}x EBIT")
        
    dte = metrics.get('debt_to_equity')
    if is_valid_metric(dte):
        if float(dte) < 0.2: working.append(f"Balance Sheet Strength — Virtually debt-free (D/E: {float(dte):.2f})")
        elif float(dte) > 1.5: not_working.append(f"Leverage Risk — High Debt-to-Equity at {float(dte):.2f}x")
        
    yoy = to_float(metrics.get('pat_yoy'))
    if yoy and yoy > 20: working.append(f"Strong Earnings Growth — PAT up {yoy:.2f}% YoY")
    elif yoy and yoy < 0: not_working.append(f"Earnings Contraction — PAT down {yoy:.2f}% YoY")
    
    return working, not_working

def render_highlights_card(working, not_working):
    st.markdown("### Key Drivers & Operational Highlights")
    col_pos, col_neg = st.columns(2)
    with col_pos:
        st.markdown(f"##### 🟢 What's Working Well?")
        if working:
            for w in working:
                st.markdown(
                    f"<div style='background:rgba(63,185,80,0.1); border-left:3px solid {GREEN}; "
                    f"padding:8px 12px; margin-bottom:8px; border-radius:4px; font-size:0.9em; color:#E6E6E6;'>"
                    f"• {html_escape(str(w))}</div>",
                    unsafe_allow_html=True)
        else:
            st.caption("No significant positive extremes detected.")
    with col_neg:
        st.markdown(f"##### 🔴 What's Not Working Well?")
        if not_working:
            for nw in not_working:
                st.markdown(
                    f"<div style='background:rgba(248,81,73,0.1); border-left:3px solid {RED}; "
                    f"padding:8px 12px; margin-bottom:8px; border-radius:4px; font-size:0.9em; color:#E6E6E6;'>"
                    f"• {html_escape(str(nw))}</div>",
                    unsafe_allow_html=True)
        else:
            st.caption("No major balance sheet red flags detected.")

# --- ANGEL ONE COMPONENT: CORPORATE EVENTS & MF ---
def render_corporate_events_and_mfs(cal_df, mf_df):
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("##### 📅 Corporate Events")
        if cal_df is not None and not cal_df.empty:
            mask = cal_df['Event'].astype(str).str.contains('High|Low|Average|Revenue', case=False, na=False)
            cal_df_clean = cal_df[~mask]
            st.dataframe(cal_df_clean, use_container_width=True, hide_index=True)
        else: st.caption("No upcoming corporate events found.")
    with c2:
        st.markdown("##### 🏦 Top Mutual Funds Invested")
        if mf_df is not None and not mf_df.empty:
            try:
                df_clean = mf_df[["Holder", "Shares", "% Out"]].rename(columns={"Holder": "Mutual Fund Scheme", "Shares": "Shares Held", "% Out": "% Stake"})
                df_clean["% Stake"] = df_clean["% Stake"].apply(lambda x: f"{x * 100:.2f}%" if pd.notna(x) else "N/A")
                st.dataframe(df_clean, use_container_width=True, hide_index=True)
            except Exception: st.dataframe(mf_df, use_container_width=True)
        else: st.caption("No Mutual Fund scheme data available.")

def custom_metric(label, value):
    st.markdown(
        f'<div style="background-color: {CARD_BG}; border: 1px solid {BORDER}; padding: 12px 15px; '
        f'border-radius: 8px; margin-bottom: 12px;">'
        f'<div style="font-size: 11px; color: {MUTED}; text-transform: uppercase; font-weight: 600; margin-bottom: 4px;">'
        f'{html_escape(str(label))}</div>'
        f'<div style="font-size: 20px; font-weight: 700; color: #FFFFFF;">{html_escape(str(value))}</div></div>',
        unsafe_allow_html=True)

def card(title, body_html):
    st.markdown(
        f'<div class="swf-card"><div class="swf-h">{html_escape(str(title))}</div>{body_html}</div>',
        unsafe_allow_html=True)

# ============================================================
# 9. AI NARRATIVE
# ============================================================
def generate_comprehensive_report(metrics, ticker):
    client = genai.Client(api_key=GEMINI_KEY)
    sys = """You are a research narrative synthesis layer over a quantitative screening model.
You are NOT an independent senior equity analyst with access to filings, auditor notes, or
segment economics. Explain and stress-test the quantitative outputs only.

Output exactly 8 numbered sections:
1. VALUATION & FAIR VALUE
2. FUTURE GROWTH & OUTLOOK
3. PAST PERFORMANCE & EARNINGS QUALITY
4. FINANCIAL HEALTH & BALANCE SHEET
5. DIVIDEND & CAPITAL ALLOCATION
6. MANAGEMENT & COMPENSATION
7. OWNERSHIP STRUCTURE & INSIDER SENTIMENT
8. NARRATIVE VERDICT
Provide ONLY narrative reasoning — no invented numbers beyond what is given to you.

REALITY CHECKER MANDATE:
- If implied upside/downside is extreme (beyond +150% or beyond -50%), say so and urge caution.
- Treat news keyword signals as weak evidence only.
- Prefer Bear/Base/Bull ranges over any single target price when ranges are provided.
- State that composite scores are model scores, not calibrated probabilities.

NO BLIND AGREEMENT MANDATE:
- Quantitative baseline and forward catalysts can disagree; weigh both and explain.
- Do not upgrade a weak quantitative case purely because of optimistic language."""
    pred = metrics.get('predictive', {})
    news_titles = "; ".join([n['title'] for n in (metrics.get('recent_news') or [])[:5]]) or "No recent headlines found."
    turnaround_note = " TURNAROUND flagged." if metrics.get('is_turnaround') else ""
    order_book_note = (f" Forward catalyst signal(s) detected in recent news: {', '.join(metrics.get('order_book_hits', [])[:4])}."
                        if metrics.get('order_book_hits') else " No explicit order-book/guidance signal detected in recent news.")
    
    target_display = f"{metrics['currency']}{pred.get('target_price')}" if pred.get('verdict') != "DON'T BUY" else "N/A (Model Rejected due to strict veto)"
    
    pmt = (f"Target: {metrics['name']} ({ticker}). Sector: {metrics.get('sector')} "
           f"(profile: {metrics.get('sector_profile')}).{turnaround_note}{order_book_note} "
           f"Price: {metrics['price']}. P/E: {metrics['pe_ratio']}. P/B: {metrics['pb_ratio']}. "
           f"EV/EBITDA: {metrics['ev_ebitda']}. Debt/Eq: {metrics['debt_to_equity']}. "
           f"Valuation model used: {pred.get('model_used')}. Forward growth assumption used in the model: "
           f"{pred.get('growth_used')}%. Quantitative Target Price: {target_display}. "
           f"System Verdict: {pred.get('verdict')} (composite score {pred.get('composite_score')}/100 — "
           f"fundamental {pred.get('fundamental_score')}, intrinsic {pred.get('intrinsic_score')}, "
           f"technical {pred.get('technical_score')}). Recent news headlines: {news_titles}")
    return client.models.generate_content(model='gemini-3.5-flash-lite', contents=pmt,
                                          config=types.GenerateContentConfig(system_instruction=sys, temperature=0.2)).text


# ============================================================
# IPO FEATURE — DATA ENGINE (ipomarket.in primary + graceful fallbacks)
# ============================================================
from datetime import datetime, timedelta
from html import escape as _esc

_IPO_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "en-IN,en;q=0.9",
}

def _parse_date_flex(s):
    if not s:
        return None
    s = re.sub(r"[⏱⏰].*$", "", str(s)).strip()
    s = re.sub(r"\s+\d+h.*$", "", s).strip()
    for fmt in ("%d %b %Y", "%d-%b-%Y", "%d/%m/%Y", "%Y-%m-%d", "%d %B %Y", "%b %d, %Y"):
        try:
            return datetime.strptime(s[:20].strip(), fmt).date()
        except ValueError:
            continue
    return None

def _parse_money_inr(s):
    if s is None:
        return None
    t = str(s).replace(",", "").replace("₹", "").replace("Rs.", "").replace("Rs", "").strip()
    m = re.search(r"([\d.]+)\s*(Cr|crore)?", t, re.I)
    if not m:
        return None
    try:
        v = float(m.group(1))
        if m.group(2):
            return v  # already in Cr
        return v
    except ValueError:
        return None

def _parse_gmp(s):
    """Return (gmp_rupees, gmp_pct) from strings like 'GMP ₹34 ( +35.05% )'."""
    if not s or str(s).strip() in ("—", "-", "N/A", ""):
        return None, None
    t = str(s)
    rupees = None
    pct = None
    m = re.search(r"₹\s*([\d.]+)", t)
    if m:
        try:
            rupees = float(m.group(1))
        except ValueError:
            pass
    m2 = re.search(r"([+-]?[\d.]+)\s*%", t)
    if m2:
        try:
            pct = float(m2.group(1))
        except ValueError:
            pass
    return rupees, pct

def _parse_price_band(s):
    if not s:
        return None, None
    t = str(s).replace("₹", "").replace(",", "")
    nums = re.findall(r"[\d.]+", t)
    if len(nums) >= 2:
        return float(nums[0]), float(nums[1])
    if len(nums) == 1:
        return float(nums[0]), float(nums[0])
    return None, None

def _slug_from_href(href):
    if not href:
        return None
    m = re.search(r"/ipo/([a-z0-9\-]+)", href)
    return m.group(1) if m else None

def _classify_bucket(open_d, close_d, listing_d, status_hint=None):
    today = datetime.today().date()
    st = (status_hint or "").upper()
    if st in ("OPEN", "CURRENT"):
        return "current"
    if st in ("LISTED", "CLOSED") and listing_d and listing_d <= today:
        return "closed"
    if open_d and open_d > today:
        return "upcoming"
    if open_d and close_d and open_d <= today <= close_d:
        return "current"
    if close_d and close_d < today:
        return "closed"
    if listing_d and listing_d <= today:
        return "closed"
    if open_d and open_d > today:
        return "upcoming"
    return "upcoming"

@st.cache_data(ttl=1800, show_spinner=False)
def _scrape_ipomarket_list(path: str) -> list:
    """Scrape a list page from ipomarket.in (/ipo/open, /ipo/upcoming, /ipo/listed)."""
    url = f"https://www.ipomarket.in{path}"
    try:
        r = requests.get(url, headers=_IPO_HEADERS, timeout=20)
        if r.status_code != 200:
            logger.warning("ipomarket list %s status %s", path, r.status_code)
            return []
        soup = BeautifulSoup(r.text, "html.parser")
    except Exception as e:
        logger.warning("ipomarket list fetch failed %s: %s", path, e)
        return []

    results, seen = [], set()
    for table in soup.find_all("table"):
        rows = table.find_all("tr")
        if not rows:
            continue
        headers = [c.get_text(" ", strip=True).lower() for c in rows[0].find_all(["th", "td"])]
        if not any("company" in h for h in headers):
            continue
        for row in rows[1:]:
            cells = row.find_all(["td", "th"])
            if len(cells) < 3:
                continue
            texts = [c.get_text(" ", strip=True) for c in cells]
            link = None
            for a in row.find_all("a", href=True):
                if "/ipo/" in a["href"] and "affiliate" not in a["href"]:
                    link = a["href"]
                    break
            slug = _slug_from_href(link) or re.sub(r"[^a-z0-9]+", "-", texts[0].lower())[:60]
            if slug in seen:
                continue
            seen.add(slug)

            # Map columns loosely by header keywords
            def col(keys, default=""):
                for i, h in enumerate(headers):
                    if any(k in h for k in keys) and i < len(texts):
                        return texts[i]
                return default

            name_raw = texts[0]
            name = re.sub(r"^[A-Z]{1,3}\s+", "", name_raw)
            name = re.sub(r"\s+(Agriculture|Others|Mainboard|SME)$", "", name).strip()
            status = col(["status"], "OPEN" if "open" in path else ("LISTED" if "listed" in path else "UPCOMING"))
            open_s = col(["open", "expected"])
            close_s = col(["close"])
            band_s = col(["price band", "price"])
            lot_s = col(["lot"])
            min_inv = col(["min"])
            gmp_s = col(["gmp"])
            sub_s = col(["subscription", "subs"])
            issue_s = col(["issue size", "size"])
            plo, phi = _parse_price_band(band_s)
            gmp_rs, gmp_pct = _parse_gmp(gmp_s)
            open_d = _parse_date_flex(open_s)
            close_d = _parse_date_flex(close_s)

            bucket = "current" if "open" in path else ("closed" if "listed" in path else "upcoming")
            results.append({
                "symbol": slug,
                "slug": slug,
                "name": name,
                "status": status,
                "bucket": bucket,
                "date": open_s or "",
                "open_date": open_d.isoformat() if open_d else None,
                "close_date": close_d.isoformat() if close_d else None,
                "price_low": plo,
                "price_high": phi,
                "price_band_str": band_s or "",
                "lot_size": lot_s if lot_s not in ("TBA", "—", "") else None,
                "min_investment": min_inv if min_inv not in ("TBA", "—", "") else None,
                "gmp": gmp_rs,
                "gmp_pct": gmp_pct,
                "gmp_str": gmp_s if gmp_s not in ("—", "") else None,
                "subscription_str": sub_s if sub_s not in ("—", "") else None,
                "issue_size_cr": _parse_money_inr(issue_s),
                "issue_size_str": issue_s or "",
                "exchange": "NSE/BSE",
                "detail_url": f"https://www.ipomarket.in/ipo/{slug}",
                "source": "ipomarket",
            })
    return results



@st.cache_data(ttl=1800, show_spinner=False)
def _scrape_chittorgarh_dashboard() -> list:
    """Primary calendar / name list from Chittorgarh IPO dashboard (best-effort).
    Review-page links are server-rendered; structured GMP/price often needs a secondary source.
    """
    out, seen = [], set()
    try:
        r = requests.get("https://www.chittorgarh.com/ipo/", headers=_IPO_HEADERS, timeout=20)
        if r.status_code != 200:
            return out
        soup = BeautifulSoup(r.text, "html.parser")
        for a in soup.find_all("a", href=True):
            href = a.get("href", "")
            t = a.get_text(" ", strip=True)
            if "/ipo_review/" not in href:
                continue
            if not t or len(t) > 100:
                continue
            name = re.sub(r"\s+IPO$", "", t).strip()
            if not name or name.lower() in ("ipo", "sme ipo"):
                continue
            slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
            if slug in seen:
                continue
            seen.add(slug)
            full = ("https://www.chittorgarh.com" + href) if href.startswith("/") else href
            out.append({
                "symbol": slug, "slug": slug, "name": name,
                "status": "CURRENT", "bucket": "current",
                "date": "", "open_date": None, "close_date": None,
                "price_low": None, "price_high": None, "price_band_str": "",
                "lot_size": None, "min_investment": None,
                "gmp": None, "gmp_pct": None, "gmp_str": None,
                "subscription_str": None, "issue_size_cr": None, "issue_size_str": "",
                "exchange": "NSE/BSE",
                "detail_url": full,
                "chittorgarh_url": full,
                "source": "chittorgarh",
            })
    except Exception as e:
        logger.warning("Chittorgarh dashboard scrape failed: %s", e)
    return out



@st.cache_data(ttl=1800, show_spinner=False)
def _scrape_screener_ipo_list() -> dict:
    """Primary structured IPO data from Screener.in (/ipo/ and /ipo/recent/).
    Returns {current: [...], closed: [...], upcoming: [...]} with subscription, PE, ROCE, links.
    """
    out = {"current": [], "closed": [], "upcoming": []}
    H = _IPO_HEADERS

    def _parse_period(period):
        # '11th Aug - 13th Aug' or with years. Infer year near year-end boundaries.
        if not period or period in ("-", "—", ""):
            return None, None, ""
        period = period.replace("th", "").replace("st", "").replace("nd", "").replace("rd", "")
        parts = re.split(r"\s*[-–]\s*", period)
        today = datetime.today().date()
        year = today.year

        def _with_year(piece):
            piece = piece.strip()
            if re.search(r"\d{4}", piece):
                return _parse_date_flex(piece)
            # Try current year, then adjacent year if result is far from today
            d0 = _parse_date_flex(f"{piece} {year}")
            if d0 is None:
                return None
            # If date is > 6 months in the past, try year+1; if > 6 months future from adjacent, try year-1
            delta = (d0 - today).days
            if delta < -180:
                d1 = _parse_date_flex(f"{piece} {year + 1}")
                if d1 is not None:
                    return d1
            if delta > 200:
                d1 = _parse_date_flex(f"{piece} {year - 1}")
                if d1 is not None and abs((d1 - today).days) < abs(delta):
                    return d1
            return d0

        open_d = _with_year(parts[0]) if parts else None
        close_d = _with_year(parts[1]) if len(parts) > 1 else None
        return open_d, close_d, period

    # ---- Current / open issues ----
    try:
        r = requests.get("https://www.screener.in/ipo/", headers=H, timeout=20)
        if r.status_code == 200:
            soup = BeautifulSoup(r.text, "html.parser")
            main = None
            for t in soup.find_all("table"):
                hdrs = [c.get_text(" ", strip=True) for c in (t.find_all("tr")[0].find_all(["th", "td"]) if t.find_all("tr") else [])]
                if hdrs and hdrs[0] == "Name" and any("Subscription Period" in h for h in hdrs):
                    main = t
                    break
            if main:
                for row in main.find_all("tr")[1:]:
                    a = row.find("a", href=re.compile(r"/company/"))
                    if not a:
                        continue
                    cells = row.find_all("td", recursive=False) or row.find_all("td")
                    texts = [c.get_text(" ", strip=True) for c in cells]
                    if len(texts) < 4:
                        continue
                    name = re.sub(r"\s+", " ", re.sub(r"\s*(NSE|BSE)\s*", " ", a.get_text(" ", strip=True))).strip()
                    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
                    sub_text = texts[5] if len(texts) > 5 else ""
                    def _times(label):
                        m = re.search(rf"{label}.*?([\d.]+)\s*times", sub_text, re.I)
                        return float(m.group(1)) if m else None
                    total = _times("Total")
                    qib = _times("Institutional")
                    nii = _times("Non-Institutional")
                    retail = _times("Retail")
                    open_d, close_d, period = _parse_period(texts[1] if len(texts) > 1 else "")
                    plo, phi = _parse_price_band(texts[2] if len(texts) > 2 else "")
                    listing_s = texts[3] if len(texts) > 3 else ""
                    mcap = texts[4] if len(texts) > 4 else ""
                    pe_s = texts[6] if len(texts) > 6 else ""
                    roce_s = texts[7] if len(texts) > 7 else ""
                    pe = None
                    try:
                        pe = float(re.sub(r"[^\d.]", "", pe_s)) if pe_s and any(ch.isdigit() for ch in pe_s) else None
                    except ValueError:
                        pe = None
                    roce = None
                    mroce = re.search(r"([+-]?[\d.]+)", roce_s or "")
                    if mroce:
                        try:
                            roce = float(mroce.group(1))
                        except ValueError:
                            pass
                    today = datetime.today().date()
                    if open_d and open_d > today:
                        bucket = "upcoming"
                    elif close_d and close_d < today:
                        bucket = "closed"
                    else:
                        bucket = "current"
                    rec = {
                        "symbol": slug, "slug": slug, "name": name,
                        "status": bucket.upper(), "bucket": bucket,
                        "date": period, "open_date": open_d.isoformat() if open_d else None,
                        "close_date": close_d.isoformat() if close_d else None,
                        "price_low": plo, "price_high": phi,
                        "price_band_str": texts[2] if len(texts) > 2 else "",
                        "lot_size": None, "min_investment": None,
                        "gmp": None, "gmp_pct": None, "gmp_str": None,
                        "subscription_str": f"{total}x" if total is not None else None,
                        "subscription_total": total,
                        "subscription_qib": qib,
                        "subscription_nii": nii,
                        "subscription_retail": retail,
                        "issue_size_cr": _parse_money_inr(mcap),
                        "issue_size_str": f"₹{mcap} Cr" if mcap else "",
                        "listing_date_str": listing_s,
                        "pe_ipo": pe, "roce_ipo": roce,
                        "exchange": "NSE/BSE",
                        "detail_url": "https://www.screener.in" + a["href"],
                        "screener_url": "https://www.screener.in" + a["href"],
                        "source": "screener",
                    }
                    out[bucket].append(rec)
    except Exception as e:
        logger.warning("Screener IPO list failed: %s", e)

    # ---- Recent / closed listings ----
    try:
        r = requests.get("https://www.screener.in/ipo/recent/", headers=H, timeout=20)
        if r.status_code == 200:
            soup = BeautifulSoup(r.text, "html.parser")
            for t in soup.find_all("table"):
                hdrs = [c.get_text(" ", strip=True) for c in (t.find_all("tr")[0].find_all(["th", "td"]) if t.find_all("tr") else [])]
                if not (hdrs and "Listing Date" in hdrs and "IPO Price" in " ".join(hdrs)):
                    continue
                for row in t.find_all("tr")[1:]:
                    a = row.find("a", href=re.compile(r"/company/"))
                    if not a:
                        continue
                    cells = [c.get_text(" ", strip=True) for c in row.find_all("td")]
                    name = a.get_text(" ", strip=True)
                    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
                    if any(x["slug"] == slug for x in out["closed"]):
                        continue
                    ipo_price = None
                    m = re.search(r"([\d.]+)", cells[3] if len(cells) > 3 else "")
                    if m:
                        ipo_price = float(m.group(1))
                    cur_price = None
                    m = re.search(r"([\d.]+)", cells[4] if len(cells) > 4 else "")
                    if m:
                        cur_price = float(m.group(1))
                    chg = None
                    m = re.search(r"([+-]?[\d.]+)\s*%", cells[5] if len(cells) > 5 else "")
                    if m:
                        chg = float(m.group(1))
                    elif ipo_price and cur_price and ipo_price > 0:
                        chg = round((cur_price / ipo_price - 1) * 100, 2)
                    out["closed"].append({
                        "symbol": slug, "slug": slug, "name": name,
                        "status": "CLOSED", "bucket": "closed",
                        "date": cells[1] if len(cells) > 1 else "",
                        "open_date": None, "close_date": None,
                        "price_low": ipo_price, "price_high": ipo_price,
                        "price_band_str": cells[3] if len(cells) > 3 else "",
                        "lot_size": None, "min_investment": None,
                        "gmp": None, "gmp_pct": None, "gmp_str": None,
                        "subscription_str": None, "subscription_total": None,
                        "issue_size_cr": _parse_money_inr(cells[2] if len(cells) > 2 else ""),
                        "issue_size_str": cells[2] if len(cells) > 2 else "",
                        "listing_date_str": cells[1] if len(cells) > 1 else "",
                        "listing_price": cur_price,
                        "listing_gain_pct": chg,
                        "exchange": "NSE/BSE",
                        "detail_url": "https://www.screener.in" + a["href"],
                        "screener_url": "https://www.screener.in" + a["href"],
                        "source": "screener",
                    })
    except Exception as e:
        logger.warning("Screener recent IPO list failed: %s", e)

    return out


@st.cache_data(ttl=3600, show_spinner=False)
def _screener_company_lookup(name: str, screener_url: str = None) -> dict:
    """Pull about + multi-year Sales/PAT from a Screener company page (IPO or listed)."""
    result = {}
    H = _IPO_HEADERS
    try:
        link = screener_url
        if not link and name:
            q = requests.utils.quote(name)
            r = requests.get(f"https://www.screener.in/search/?q={q}", headers=H, timeout=12)
            if r.status_code == 200:
                soup = BeautifulSoup(r.text, "html.parser")
                for a in soup.find_all("a", href=True):
                    if a["href"].startswith("/company/"):
                        link = "https://www.screener.in" + a["href"].split("?")[0]
                        break
        if not link:
            return result
        if not link.startswith("http"):
            link = "https://www.screener.in" + link
        result["screener_url"] = link
        r2 = requests.get(link, headers=H, timeout=20)
        if r2.status_code != 200:
            return result
        soup2 = BeautifulSoup(r2.text, "html.parser")
        # About
        about_el = soup2.select_one(".company-info, #top .about, .about")
        if about_el:
            result["about_screener"] = about_el.get_text(" ", strip=True)[:1200]
        else:
            # fallback paragraph under company header
            for p in soup2.find_all("p"):
                t = p.get_text(" ", strip=True)
                if len(t) > 80 and ("incorporated" in t.lower() or "business" in t.lower() or "Ltd" in t):
                    result["about_screener"] = t[:1200]
                    break
        # Profit & Loss / financial table with Sales
        financials = []
        for t in soup2.find_all("table"):
            rows = t.find_all("tr")
            if not rows:
                continue
            hdrs = [c.get_text(" ", strip=True) for c in rows[0].find_all(["th", "td"])]
            if not any(re.search(r"Mar|Jan|Dec|202[0-9]", h) for h in hdrs):
                continue
            # map year columns
            years = hdrs[1:]
            sales_row = pat_row = None
            for row in rows[1:]:
                cells = [c.get_text(" ", strip=True) for c in row.find_all(["td", "th"])]
                if not cells:
                    continue
                label = cells[0].lower()
                if sales_row is None and ("sales" in label or "revenue" in label):
                    sales_row = cells[1:]
                if pat_row is None and (label.startswith("net profit") or label == "pat" or "net profit" in label):
                    pat_row = cells[1:]
            if sales_row:
                for i, y in enumerate(years):
                    if i >= len(sales_row):
                        break
                    rev = _parse_money_inr(sales_row[i])
                    pat = _parse_money_inr(pat_row[i]) if pat_row and i < len(pat_row) else None
                    if rev is None and sales_row[i] not in ("", "-", "—"):
                        try:
                            rev = float(str(sales_row[i]).replace(",", ""))
                        except ValueError:
                            pass
                    if pat is None and pat_row and i < len(pat_row) and pat_row[i] not in ("", "-", "—"):
                        try:
                            pat = float(str(pat_row[i]).replace(",", ""))
                        except ValueError:
                            pass
                    financials.append({"year": y, "revenue_cr": rev, "pat_cr": pat, "eps": None, "raw": [y, sales_row[i] if i < len(sales_row) else ""]})
                if financials:
                    break
        if financials:
            # Screener columns are oldest→newest left to right; reverse for latest-first
            financials = list(reversed(financials))
            result["financials"] = financials
            revs = [f["revenue_cr"] for f in financials if f.get("revenue_cr")]
            # latest first: revs[0] is latest
            if len(revs) >= 2 and revs[-1] and revs[-1] > 0:
                years_n = len(revs) - 1
                try:
                    result["revenue_cagr"] = round(((revs[0] / revs[-1]) ** (1 / years_n) - 1) * 100, 2)
                except Exception:
                    result["revenue_cagr"] = None
            pats = [f["pat_cr"] for f in financials if f.get("pat_cr") is not None]
            if pats:
                result["is_profitable_latest"] = pats[0] > 0
                result["is_profitable_all"] = all(p > 0 for p in pats[:3])
        # top ratios
        ratios = {}
        for li in soup2.select("#top-ratios li, ul#top-ratios li, .company-ratios li"):
            t = li.get_text(" ", strip=True)
            if ":" in t:
                k, v = t.split(":", 1)
                ratios[k.strip()] = v.strip()
        if ratios:
            result["screener_ratios"] = ratios
    except Exception as e:
        logger.warning("Screener company lookup failed for %s: %s", name, e)
    return result


def _ai_google_gmp(company_name: str) -> dict:
    """Enrich GMP via Google News headlines + optional Gemini extraction.
    Returns {gmp, gmp_pct, gmp_str, gmp_source, gmp_note}.
    """
    result = {"gmp": None, "gmp_pct": None, "gmp_str": None, "gmp_source": None, "gmp_note": None}
    if not company_name:
        return result
    headlines = fetch_google_news(f"{company_name} IPO GMP grey market premium")
    titles = [h.get("title", "") for h in headlines]
    blob = " | ".join(titles)
    # deterministic parse from headlines first
    m = re.search(r"GMP[^\d₹]*₹?\s*([\d.]+)\s*(?:\(?\s*([+-]?[\d.]+)\s*%\s*\)?)?", blob, re.I)
    if not m:
        m = re.search(r"(?:grey market|gmp)\s*(?:premium)?[^\d₹]*₹?\s*([\d.]+)", blob, re.I)
    if m:
        try:
            result["gmp"] = float(m.group(1))
            if m.lastindex and m.lastindex >= 2 and m.group(2):
                result["gmp_pct"] = float(m.group(2))
            result["gmp_str"] = f"GMP ₹{result['gmp']}" + (f" ({result['gmp_pct']:+.1f}%)" if result.get("gmp_pct") is not None else "")
            result["gmp_source"] = "google_news_headlines"
            result["gmp_note"] = "Parsed from public news headlines; unofficial grey-market indicator."
            return result
        except (TypeError, ValueError):
            pass

    # Gemini assist if key present
    if GEMINI_KEY and titles:
        try:
            client = genai.Client(api_key=GEMINI_KEY)
            prompt = (
                f"From these news headlines about the Indian IPO '{company_name}', extract the "
                "latest Grey Market Premium if mentioned. Return ONLY JSON: "
                '{"gmp_rupees": number|null, "gmp_pct": number|null, "confidence": 0-1, "note": "..."}. '
                "If not clearly stated, use nulls. Headlines:\n- " + "\n- ".join(titles[:6])
            )
            resp = client.models.generate_content(
                model="gemini-2.0-flash", contents=prompt,
                config=types.GenerateContentConfig(temperature=0.0))
            text = (resp.text or "").strip()
            mjson = re.search(r"\{[^{}]+\}", text, re.S)
            if mjson:
                import json as _json
                data = _json.loads(mjson.group(0))
                if data.get("gmp_rupees") is not None:
                    result["gmp"] = float(data["gmp_rupees"])
                if data.get("gmp_pct") is not None:
                    result["gmp_pct"] = float(data["gmp_pct"])
                if result["gmp"] is not None:
                    result["gmp_str"] = f"GMP ₹{result['gmp']}" + (
                        f" ({result['gmp_pct']:+.1f}%)" if result.get("gmp_pct") is not None else "")
                    result["gmp_source"] = "ai_news_extraction"
                    result["gmp_note"] = data.get("note") or "AI-extracted from news; verify independently. Unofficial."
        except Exception as e:
            logger.warning("AI GMP lookup failed for %s: %s", company_name, e)
    return result


def _merge_ipo_records(primary: list, secondary: list) -> list:
    """Merge by normalized name/slug; secondary fills missing hard fields."""
    def key(x):
        return re.sub(r"[^a-z0-9]", "", (x.get("name") or x.get("slug") or "").lower())
    by = {}
    for rec in primary:
        by[key(rec)] = dict(rec)
    for rec in secondary:
        k = key(rec)
        if k not in by:
            by[k] = dict(rec)
            continue
        base = by[k]
        for field in ("price_low", "price_high", "price_band_str", "lot_size", "min_investment",
                      "gmp", "gmp_pct", "gmp_str", "subscription_str", "issue_size_cr",
                      "issue_size_str", "detail_url", "open_date", "close_date", "date"):
            if base.get(field) in (None, "", []) and rec.get(field) not in (None, "", []):
                base[field] = rec[field]
        src = base.get("source", "")
        if rec.get("source") and rec["source"] not in src:
            base["source"] = f"{src}+{rec['source']}" if src else rec["source"]
        by[k] = base
    return list(by.values())


@st.cache_data(ttl=1800, show_spinner=False)

def fetch_ipo_list_categorized() -> dict:
    """Hybrid IPO lists with Screener.in as primary structured source.
    Chain: Screener (subscription, PE, ROCE, financials links)
         → Chittorgarh (names/calendar)
         → ipomarket (GMP + lot size)
         → FMP last resort
    """
    scr = _scrape_screener_ipo_list()
    chitt = _scrape_chittorgarh_dashboard()
    im_current = _scrape_ipomarket_list("/ipo/open")
    im_upcoming = _scrape_ipomarket_list("/ipo/upcoming")
    im_closed = _scrape_ipomarket_list("/ipo/listed")

    current = _merge_ipo_records(scr.get("current") or [], im_current)
    current = _merge_ipo_records(current, [x for x in chitt if x.get("bucket") == "current"])
    for x in current:
        x["bucket"] = "current"
        x["status"] = x.get("status") or "OPEN"

    upcoming = _merge_ipo_records(scr.get("upcoming") or [], im_upcoming)
    upcoming = _merge_ipo_records(upcoming, [x for x in chitt if x.get("bucket") == "upcoming"])
    for x in upcoming:
        x["bucket"] = "upcoming"
        x["status"] = "UPCOMING"

    closed = _merge_ipo_records(scr.get("closed") or [], im_closed[:40])
    for x in closed:
        x["bucket"] = "closed"

    if not current and not upcoming:
        FMP_KEY = st.secrets.get("FMP_API_KEY", "")
        if FMP_KEY:
            try:
                today = datetime.today().strftime("%Y-%m-%d")
                sixty = (datetime.today() + timedelta(days=60)).strftime("%Y-%m-%d")
                r = requests.get(
                    f"https://financialmodelingprep.com/api/v3/ipo_calendar?from={today}&to={sixty}&apikey={FMP_KEY}",
                    timeout=8)
                if r.status_code == 200 and isinstance(r.json(), list):
                    for item in r.json():
                        if not item.get("symbol"):
                            continue
                        upcoming.append({
                            "symbol": item.get("symbol"),
                            "slug": str(item.get("symbol", "")).lower(),
                            "name": item.get("company") or item.get("name") or item.get("symbol"),
                            "status": "UPCOMING", "bucket": "upcoming",
                            "date": item.get("date") or "", "open_date": item.get("date"),
                            "close_date": None, "price_low": None, "price_high": None,
                            "price_band_str": str(item.get("priceRange") or item.get("price") or ""),
                            "lot_size": None, "min_investment": None,
                            "gmp": None, "gmp_pct": None, "gmp_str": None,
                            "subscription_str": None, "issue_size_cr": None, "issue_size_str": "",
                            "exchange": item.get("exchange") or "NSE/BSE",
                            "detail_url": None, "source": "FMP",
                        })
            except Exception as e:
                logger.warning("FMP IPO fallback failed: %s", e)

    return {
        "current": current,
        "closed": closed[:40],
        "upcoming": upcoming,
        "fetched_at": datetime.now().isoformat(timespec="seconds"),
        "sources_note": (
            "Primary: Screener.in (subscription, PE/ROCE, financials). "
            "GMP: ipomarket / news-AI. Calendar names: Chittorgarh."
        ),
    }

@st.cache_data(ttl=1800, show_spinner=False)
def fetch_ipo_detail(slug: str, company_name: str = "") -> dict:
    """Scrape ipomarket detail page for hard numbers + qualitative sections."""
    detail = {
        "symbol": slug,
        "slug": slug,
        "name": company_name or slug.replace("-", " ").title(),
        "source": "ipomarket",
        "detail_url": f"https://www.ipomarket.in/ipo/{slug}",
    }
    url = detail["detail_url"]
    try:
        r = requests.get(url, headers=_IPO_HEADERS, timeout=20)
        if r.status_code != 200:
            detail["error"] = f"Detail page status {r.status_code}"
            return detail
        soup = BeautifulSoup(r.text, "html.parser")
    except Exception as e:
        detail["error"] = str(e)
        return detail

    # Key-value tables
    kv = {}
    for table in soup.find_all("table"):
        rows = table.find_all("tr")
        if not rows:
            continue
        # 2-col KV
        if all(len(tr.find_all(["td", "th"])) == 2 for tr in rows[: min(5, len(rows))]):
            for tr in rows:
                cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
                if len(cells) == 2:
                    kv[cells[0].strip().lower()] = cells[1].strip()
        # Financial history header
        headers = [c.get_text(" ", strip=True).lower() for c in rows[0].find_all(["td", "th"])]
        if any("revenue" in h for h in headers) and any("fiscal" in h or "year" in h for h in headers):
            fin_rows = []
            for tr in rows[1:]:
                cells = [c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])]
                if len(cells) >= 3:
                    fin_rows.append({
                        "year": cells[0],
                        "revenue_cr": _parse_money_inr(cells[1]),
                        "pat_cr": _parse_money_inr(cells[2]) if len(cells) > 2 else None,
                        "eps": cells[3] if len(cells) > 3 else None,
                        "raw": cells,
                    })
            if fin_rows:
                detail["financials"] = fin_rows

    # Map common keys
    def g(*keys):
        for k in keys:
            for hk, hv in kv.items():
                if k in hk:
                    return hv
        return None

    detail["issue_size_str"] = g("issue size")
    detail["fresh_issue_str"] = g("fresh issue", "fresh capital")
    detail["ofs_str"] = g("ofs", "offer for sale")
    detail["face_value"] = g("face value")
    detail["exchange"] = g("exchange") or "NSE/BSE"
    detail["registrar"] = g("registrar")
    detail["isin"] = g("isin")
    detail["lot_size"] = g("lot size")
    detail["issue_price"] = g("issue price", "final price")
    detail["price_band_str"] = g("price band")
    detail["listing_date_str"] = g("listing", "listed on")
    detail["open_date_str"] = g("ipo open", "open")
    detail["close_date_str"] = g("ipo close", "close")

    # Offer type
    fresh = detail.get("fresh_issue_str") or ""
    ofs = detail.get("ofs_str") or ""
    if fresh and ofs and "—" not in fresh and "—" not in ofs:
        detail["offer_type"] = f"Fresh Issue ({fresh}) + OFS ({ofs})"
    elif fresh and "—" not in fresh and fresh not in ("", "0"):
        detail["offer_type"] = f"Fresh Issue ({fresh})"
    elif ofs and "—" not in ofs:
        detail["offer_type"] = f"Offer for Sale ({ofs})"
    else:
        detail["offer_type"] = "See RHP / issue documents"

    # About + strengths + risks from text blocks
    full_text = soup.get_text("\n", strip=True)
    about = ""
    for marker in ("About\n", "About the Company", "About "):
        idx = full_text.find(marker)
        if idx >= 0:
            chunk = full_text[idx: idx + 800]
            about = re.sub(r"^About[^\n]*\n?", "", chunk).strip()
            about = about.split("Strengths")[0].split("Risk")[0].strip()
            break
    detail["about"] = about or detail.get("longBusinessSummary") or "Business description not available from aggregator."

    strengths, risks = [], []
    for line in full_text.split("\n"):
        line = line.strip()
        if line.startswith("•") or line.startswith("-"):
            item = line.lstrip("•- ").strip()
            if len(item) < 20:
                continue
            low = item.lower()
            # Filter boilerplate risks
            boilerplate = any(x in low for x in [
                "general economic", "economic downturn", "theft", "natural disaster",
                "force majeure", "pandemic", "covid", "currency fluctuation",
                "interest rate risk", "political instability", "act of god",
            ])
            if any(x in low for x in ["risk", "litigation", "dependent", "concentration",
                                       "competition", "regulatory", "customer", "working capital",
                                       "promoter", "related party", "debt", "loss"]):
                if not boilerplate and len(risks) < 8:
                    risks.append(item)
            elif any(x in low for x in ["strong", "leading", "profitable", "scalable",
                                         "growth", "brand", "network", "platform",
                                         "diversified", "experienced", "market share"]):
                if len(strengths) < 8:
                    strengths.append(item)
    detail["strengths"] = strengths
    detail["risks"] = risks

    # GMP / subscription from page text
    m = re.search(r"GMP\s*₹\s*([\d.]+)\s*\(\s*([+-]?[\d.]+)\s*%", full_text)
    if m:
        detail["gmp"] = float(m.group(1))
        detail["gmp_pct"] = float(m.group(2))
    m = re.search(r"(?:Total|Overall).*?([\d.]+)\s*x", full_text, re.I)
    if m:
        detail["subscription_total"] = float(m.group(1))
    for cat, key in [("QIB", "subscription_qib"), ("NII", "subscription_nii"),
                     ("Retail", "subscription_retail"), ("RII", "subscription_retail")]:
        m = re.search(rf"{cat}[^\d]{{0,20}}([\d.]+)\s*x", full_text, re.I)
        if m:
            detail[key] = float(m.group(1))

    # Listing gains if present
    m = re.search(r"listing\s*(?:gain|return|pop)?[^\d%]*([+-]?[\d.]+)\s*%", full_text, re.I)
    if m:
        detail["listing_gain_pct"] = float(m.group(1))
    m = re.search(r"Close Price on Listing[^\d]*([\d.]+)", full_text, re.I)
    if m:
        detail["listing_price"] = float(m.group(1))

    # Financial CAGR (safe for 1–2 years)
    fins = detail.get("financials") or []
    revs = [f["revenue_cr"] for f in fins if f.get("revenue_cr")]
    pats = [f["pat_cr"] for f in fins if f.get("pat_cr") is not None]
    if len(revs) >= 2 and revs[-1] and revs[-1] > 0:
        years = len(revs) - 1
        try:
            detail["revenue_cagr"] = round(((revs[0] / revs[-1]) ** (1 / years) - 1) * 100, 2)
        except Exception:
            detail["revenue_cagr"] = None
    else:
        detail["revenue_cagr"] = None
    if pats:
        detail["is_profitable_latest"] = pats[0] is not None and pats[0] > 0
        detail["is_profitable_all"] = all(p is not None and p > 0 for p in pats[:3])
    else:
        detail["is_profitable_latest"] = None
        detail["is_profitable_all"] = None

        detail["ipo_news"] = fetch_google_news(f"{detail['name']} IPO GMP subscription 2026")

    # GMP enrichment: AI + Google News when aggregator lacks GMP (Current IPOs)
    if detail.get("gmp") is None and detail.get("gmp_pct") is None:
        gmp_info = _ai_google_gmp(detail.get("name") or "")
        for k, v in gmp_info.items():
            if v is not None and detail.get(k) is None:
                detail[k] = v
        if gmp_info.get("gmp_note"):
            detail.setdefault("data_notes", []).append(gmp_info["gmp_note"])

    # Screener.in: primary path for multi-year financials + about (current & closed IPOs)
    scr_url = detail.get("screener_url")
    scr = _screener_company_lookup(detail.get("name") or "", screener_url=scr_url)
    if scr.get("screener_url"):
        detail["screener_url"] = scr["screener_url"]
    if scr.get("about_screener"):
        if (not detail.get("about") or detail.get("about", "").startswith("Business description")
                or len(detail.get("about", "")) < 60):
            detail["about"] = scr["about_screener"]
            detail.setdefault("data_notes", []).append("About text from Screener.in")
    if scr.get("financials") and (not detail.get("financials") or len(detail.get("financials") or []) < 2):
        detail["financials"] = scr["financials"]
        detail.setdefault("data_notes", []).append("RHP-style financials from Screener.in")
    if scr.get("revenue_cagr") is not None and detail.get("revenue_cagr") is None:
        detail["revenue_cagr"] = scr["revenue_cagr"]
    if scr.get("is_profitable_latest") is not None and detail.get("is_profitable_latest") is None:
        detail["is_profitable_latest"] = scr["is_profitable_latest"]
    if scr.get("is_profitable_all") is not None and detail.get("is_profitable_all") is None:
        detail["is_profitable_all"] = scr["is_profitable_all"]
    if scr.get("screener_ratios"):
        detail["screener_ratios"] = scr["screener_ratios"]

    return detail


def score_ipo(detail: dict, bucket: str = "current") -> tuple:
    """Score only meaningful for CURRENT IPOs. Returns (score, verdict, pros, cons).
    Upcoming/Closed should not surface BUY/ABSTAIN.
    """
    if bucket != "current":
        return None, None, [], []

    pros, cons, score = [], [], 50

    cagr = detail.get("revenue_cagr")
    if cagr is not None:
        if cagr > 20:
            pros.append(f"Strong revenue CAGR of {cagr:.1f}%"); score += 10
        elif cagr > 10:
            pros.append(f"Decent revenue CAGR of {cagr:.1f}%"); score += 5
        elif cagr < 0:
            cons.append(f"Revenue contraction ({cagr:.1f}% CAGR)"); score -= 10
        else:
            cons.append(f"Slow revenue growth ({cagr:.1f}% CAGR)"); score -= 5

    if detail.get("is_profitable_all") is True:
        pros.append("Profitable across reported years"); score += 10
    elif detail.get("is_profitable_latest") is True:
        pros.append("Profitable in latest reported year"); score += 4
    elif detail.get("is_profitable_latest") is False:
        cons.append("Latest reported year was loss-making"); score -= 12

    gmp_pct = detail.get("gmp_pct")
    if gmp_pct is not None:
        # GMP is unofficial market-sentiment only — smaller weight
        if gmp_pct >= 20:
            pros.append(f"Market sentiment: elevated unofficial GMP ({gmp_pct:.1f}%)"); score += 4
        elif gmp_pct >= 5:
            pros.append(f"Market sentiment: positive unofficial GMP ({gmp_pct:.1f}%)"); score += 2
        elif gmp_pct < 0:
            cons.append(f"Market sentiment: negative unofficial GMP ({gmp_pct:.1f}%)"); score -= 5

    sub = detail.get("subscription_total")
    if sub is not None:
        if sub >= 10:
            pros.append(f"Strong subscription ({sub:.1f}x)"); score += 8
        elif sub >= 1:
            pros.append(f"Subscribed ({sub:.1f}x)"); score += 3
        else:
            cons.append(f"Weak subscription ({sub:.1f}x)"); score -= 12

    offer = (detail.get("offer_type") or "").lower()
    if "fresh" in offer and "ofs" in offer:
        pros.append("Mix of fresh capital and OFS"); score += 2
    elif "offer for sale" in offer and "fresh" not in offer:
        cons.append("Primarily Offer for Sale — limited capital for growth"); score -= 4

    if detail.get("strengths"):
        pros.append(f"{len(detail['strengths'])} business strengths noted in filings summary")
        score += min(len(detail["strengths"]), 4)
    if detail.get("risks"):
        cons.append(f"{len(detail['risks'])} business-specific risks flagged")
        score -= min(len(detail["risks"]), 4)

    score = int(min(max(score, 0), 100))
    verdict = "BUY" if score >= 60 else "ABSTAIN"
    return score, verdict, pros, cons


def ipo_ai_narrative(detail: dict, score, verdict, pros, cons, bucket: str = "current") -> str:
    try:
        if not GEMINI_KEY:
            return "AI narrative unavailable (no GEMINI_API_KEY configured)."
        client = genai.Client(api_key=GEMINI_KEY)
        if bucket == "current":
            sys = (
                "You are an IPO research synthesis layer. Write 4-6 paragraphs covering: "
                "business overview, financial health from provided RHP numbers, valuation context, "
                "key business-specific risks (ignore generic macro risks), and a final BUY or ABSTAIN "
                "recommendation consistent with the given score. Do not invent numbers."
            )
        elif bucket == "closed":
            sys = (
                "Summarize this closed IPO: issue outcome, subscription/GMP if given, and listing "
                "result if available. Do NOT give a BUY/ABSTAIN recommendation. Do not invent numbers."
            )
        else:
            sys = (
                "Summarize this upcoming IPO using available RHP-style facts. Do NOT invent GMP, "
                "subscription, or a BUY/ABSTAIN verdict. Flag missing data explicitly."
            )
        news_txt = "; ".join(n.get("title", "") for n in (detail.get("ipo_news") or [])[:4])
        prompt = (
            f"IPO: {detail.get('name')} ({detail.get('symbol')}). Bucket: {bucket}. "
            f"Offer: {detail.get('offer_type','N/A')}. Issue size: {detail.get('issue_size_str','N/A')}. "
            f"Revenue CAGR: {detail.get('revenue_cagr','N/A')}. "
            f"Profitable: {detail.get('is_profitable_latest','N/A')}. "
            f"GMP%: {detail.get('gmp_pct','N/A')}. Sub: {detail.get('subscription_total','N/A')}. "
            f"Score: {score}. Verdict: {verdict}. "
            f"Pros: {'; '.join(pros[:4]) or 'None'}. Cons: {'; '.join(cons[:4]) or 'None'}. "
            f"About: {(detail.get('about') or '')[:400]}. News: {news_txt or 'None'}."
        )
        resp = client.models.generate_content(
            model="gemini-2.0-flash", contents=prompt,
            config=types.GenerateContentConfig(system_instruction=sys, temperature=0.2))
        return resp.text
    except Exception as e:
        return f"AI narrative unavailable: {e}"


def _render_ipo_list_rows(ipos, bucket, currency="₹"):
    if not ipos:
        st.info(f"No {bucket} IPOs found from live sources right now.")
        return
    for ipo in ipos:
        sym = ipo.get("slug") or ipo.get("symbol") or ""
        name = ipo.get("name", "Unknown")
        band = ipo.get("price_band_str") or (
            f"{currency}{ipo['price_low']} – {currency}{ipo['price_high']}"
            if ipo.get("price_low") is not None else "Price TBA"
        )
        cols = st.columns([3.2, 1.4, 1.6, 1.2, 1.2])
        with cols[0]:
            st.markdown(
                f"<b>{html_escape(name)}</b><br>"
                f"<span style='color:{MUTED};font-size:0.8em;'>"
                f"{html_escape(str(sym))} · {html_escape(str(ipo.get('exchange','')))}</span>",
                unsafe_allow_html=True)
        with cols[1]:
            st.markdown(
                f"<span style='font-size:0.75em;color:{MUTED};'>Open</span><br>"
                f"<b>{html_escape(str(ipo.get('date') or ipo.get('open_date') or 'TBA'))}</b>",
                unsafe_allow_html=True)
        with cols[2]:
            st.markdown(
                f"<span style='font-size:0.75em;color:{MUTED};'>Price Band</span><br>"
                f"<b>{html_escape(str(band))}</b>",
                unsafe_allow_html=True)
        with cols[3]:
            if bucket == "current" and ipo.get("gmp_str"):
                st.markdown(
                    f"<span style='font-size:0.75em;color:{MUTED};'>GMP</span><br>"
                    f"<b style='color:{GREEN};'>{html_escape(str(ipo.get('gmp_str')))}</b>",
                    unsafe_allow_html=True)
            elif bucket == "closed":
                st.markdown(
                    f"<span style='font-size:0.75em;color:{MUTED};'>Status</span><br>"
                    f"<b>Closed/Listed</b>",
                    unsafe_allow_html=True)
            else:
                st.markdown(
                    f"<span style='font-size:0.75em;color:{MUTED};'>Status</span><br>"
                    f"<b>Upcoming</b>",
                    unsafe_allow_html=True)
        with cols[4]:
            if st.button("Analyse →", key=f"ipo_{bucket}_{sym}", use_container_width=True):
                with st.spinner(f"Loading {name}..."):
                    st.session_state.selected_ipo = sym
                    st.session_state.ipo_bucket = bucket
                    st.session_state.ipo_detail = fetch_ipo_detail(sym, name)
                    # Carry list-level fields if detail sparse
                    d = st.session_state.ipo_detail
                    for k in ("gmp", "gmp_pct", "gmp_str", "price_low", "price_high", "lot_size",
                              "min_investment", "subscription_str", "subscription_total",
                              "subscription_qib", "subscription_nii", "subscription_retail",
                              "issue_size_cr", "issue_size_str", "screener_url", "pe_ipo",
                              "roce_ipo", "listing_date_str", "listing_gain_pct", "listing_price"):
                        if d.get(k) is None and ipo.get(k) is not None:
                            d[k] = ipo[k]
                    # Prefer Screener company page for next enrichment pass
                    if ipo.get("screener_url"):
                        d["screener_url"] = ipo["screener_url"]
                        scr = _screener_company_lookup(name, screener_url=ipo["screener_url"])
                        if scr.get("financials") and not d.get("financials"):
                            d["financials"] = scr["financials"]
                        if scr.get("revenue_cagr") is not None:
                            d["revenue_cagr"] = scr["revenue_cagr"]
                        if scr.get("is_profitable_latest") is not None:
                            d["is_profitable_latest"] = scr["is_profitable_latest"]
                        if scr.get("is_profitable_all") is not None:
                            d["is_profitable_all"] = scr["is_profitable_all"]
                        if scr.get("about_screener") and (not d.get("about") or len(d.get("about","")) < 60):
                            d["about"] = scr["about_screener"]
                    st.session_state.ipo_detail = d
                st.rerun()
        st.markdown(f"<hr style='border:0;border-top:1px solid {BORDER};margin:6px 0;'>",
                    unsafe_allow_html=True)


def _render_ipo_detail_view():
    detail = st.session_state.ipo_detail or {}
    bucket = st.session_state.get("ipo_bucket") or "current"
    sym = detail.get("slug") or detail.get("symbol") or ""
    name = detail.get("name", sym)
    score, verdict, pros, cons = score_ipo(detail, bucket=bucket)
    vc = rating_color(verdict) if verdict else MUTED

    if st.button("← Back to IPO List"):
        st.session_state.selected_ipo = None
        st.session_state.ipo_detail = None
        st.session_state.ipo_bucket = None
        st.rerun()

    # Header
    right = ""
    if bucket == "current" and verdict:
        right = f"<div style='font-size:2em;font-weight:900;color:{vc};'>{verdict}</div>" \
                f"<div style='color:{MUTED};font-size:0.85em;'>Score: {score}/100</div>"
    elif bucket == "closed":
        gain = detail.get("listing_gain_pct")
        if gain is not None:
            right = f"<div style='font-size:1.4em;font-weight:800;color:{GREEN if gain>=0 else RED};'>" \
                    f"Listing {gain:+.1f}%</div>"
        else:
            right = f"<div style='color:{MUTED};'>Listing: " \
                    f"{html_escape(str(detail.get('listing_date_str') or 'Pending / see exchange'))}</div>"
    else:
        right = f"<div style='color:{ORANGE};font-weight:700;'>UPCOMING</div>"

    st.markdown(f"""
    <div class="swf-card" style="margin-bottom:18px;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;">
        <div>
          <div style="color:{MUTED};font-size:0.85em;">IPO Research · {bucket.upper()}</div>
          <div style="font-size:1.5em;font-weight:800;">{html_escape(name)}</div>
          <div style="color:{MUTED};font-size:0.9em;">
            {html_escape(str(sym))} · {html_escape(str(detail.get('exchange','NSE/BSE')))}
            · {html_escape(str(detail.get('offer_type','Offer type TBA')))}
          </div>
        </div>
        <div style="text-align:right;">{right}</div>
      </div>
    </div>
    """, unsafe_allow_html=True)

    # Metrics row — adaptive by bucket
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        custom_metric("Issue Size", detail.get("issue_size_str") or "N/A")
    with m2:
        custom_metric("Price Band", detail.get("price_band_str") or "N/A")
    with m3:
        if bucket == "upcoming":
            custom_metric("Lot Size", detail.get("lot_size") or "TBA")
        else:
            custom_metric("GMP",
                f"₹{detail['gmp']} ({detail.get('gmp_pct'):+.1f}%)"
                if detail.get("gmp") is not None and detail.get("gmp_pct") is not None
                else (detail.get("gmp_str") or ("N/A" if bucket == "upcoming" else "N/A")))
    with m4:
        if bucket == "upcoming":
            custom_metric("Revenue CAGR",
                f"{detail['revenue_cagr']}%" if detail.get("revenue_cagr") is not None else "N/A")
        else:
            sub = detail.get("subscription_total")
            custom_metric("Subscription", f"{sub:.2f}x" if sub is not None else (detail.get("subscription_str") or "N/A"))

    if bucket != "upcoming":
        s1, s2, s3 = st.columns(3)
        with s1:
            custom_metric("QIB", f"{detail['subscription_qib']:.2f}x" if detail.get("subscription_qib") is not None else "N/A")
        with s2:
            custom_metric("NII", f"{detail['subscription_nii']:.2f}x" if detail.get("subscription_nii") is not None else "N/A")
        with s3:
            custom_metric("Retail", f"{detail['subscription_retail']:.2f}x" if detail.get("subscription_retail") is not None else "N/A")

    card("Business Overview",
         f"<p style='color:#c9d1d9;font-size:0.9em;line-height:1.6;'>"
         f"{html_escape(str(detail.get('about') or 'Not available.'))}</p>")

    fins = detail.get("financials") or []
    if fins:
        st.markdown("##### RHP Financial Highlights")
        rows = []
        for f in fins[:4]:
            rows.append({
                "Year": f.get("year"),
                "Revenue (₹ Cr)": f.get("revenue_cr") if f.get("revenue_cr") is not None else "—",
                "PAT (₹ Cr)": f.get("pat_cr") if f.get("pat_cr") is not None else "—",
                "EPS": f.get("eps") or "—",
            })
        st.dataframe(rows, use_container_width=True, hide_index=True)
        if detail.get("revenue_cagr") is not None:
            st.caption(f"Revenue CAGR (from available years): {detail['revenue_cagr']}%")

    # Strengths / risks always useful
    pc1, pc2 = st.columns(2)
    with pc1:
        p_html = "".join(
            f"<div style='padding:4px 0'><span style='color:{GREEN}'>✅ {html_escape(p)}</span></div>"
            for p in (pros or detail.get("strengths") or [])[:8]
        ) or f"<div style='color:{MUTED}'>No strengths extracted.</div>"
        card("Strengths", p_html)
    with pc2:
        c_html = "".join(
            f"<div style='padding:4px 0'><span style='color:{RED}'>⚠️ {html_escape(c)}</span></div>"
            for c in (cons or detail.get("risks") or [])[:8]
        ) or f"<div style='color:{MUTED}'>No material risks extracted.</div>"
        card("Risks & Concerns", c_html)

    if detail.get("ipo_news"):
        n_html = "".join(
            f"<div style='padding:5px 0;border-bottom:1px solid {BORDER};'>"
            f"<a href='{html_escape(str(n.get('link','#')), quote=True)}' target='_blank' "
            f"rel='noopener noreferrer' style='color:{BLUE};'>🔗 {html_escape(str(n.get('title','')))}</a></div>"
            for n in detail["ipo_news"][:5])
        card("Latest IPO News", n_html)

    with st.spinner("Generating AI note..."):
        narr = ipo_ai_narrative(detail, score, verdict, pros, cons, bucket=bucket)
    card("AI Research Note",
         f"<p style='color:#c9d1d9;font-size:0.9em;line-height:1.6;white-space:pre-wrap;'>"
         f"{style_verdict_text(narr)}</p>")

    if bucket == "current" and verdict:
        st.markdown(f"""
        <div class="swf-card" style="border:2px solid {vc};text-align:center;padding:24px;margin-top:16px;">
          <div style="font-size:0.9em;color:{MUTED};margin-bottom:6px;">IPO SCREENING VERDICT (CURRENT ONLY — not a full issue-price valuation)</div>
          <div style="font-size:2.8em;font-weight:900;color:{vc};">{verdict}</div>
          <div style="color:{MUTED};font-size:0.85em;margin-top:6px;">
            Score {score}/100 · Screening model based on RHP numbers, GMP & subscription —
            not a guarantee of listing performance. Always read the RHP.
          </div>
        </div>
        """, unsafe_allow_html=True)
    elif bucket == "closed":
        st.info("Closed IPOs do not receive a BUY/ABSTAIN verdict. Review listing outcome / pending listing date above.")
    else:
        st.info("Upcoming IPOs do not show GMP, live subscription, or a BUY/ABSTAIN verdict until the issue is open.")

    notes = detail.get("data_notes") or []
    if detail.get("gmp_source"):
        notes.append(f"GMP source: {detail.get('gmp_source')}")
    if notes:
        with st.expander(f"Data notes ({len(notes)})"):
            for n in notes:
                st.markdown(f"- {html_escape(str(n))}")
    if detail.get("screener_url"):
        st.caption(f"Screener backup: {detail['screener_url']}")
    st.caption(
        "Sources: Chittorgarh (calendar) · structured issue fields from public aggregators · "
        "Screener.in backup for company text · GMP from aggregator or news/AI extraction (unofficial). "
        "Not financial advice."
    )



# ============================================================
# MODE SELECTOR + EQUITY UI
# ============================================================
st.markdown('<div class="swf-title-container"><div class="swf-title">ATHENAEUM FINANCIAL INTELLIGENCE</div></div>', unsafe_allow_html=True)

c_eq, c_ipo = st.columns(2)
with c_eq:
    if st.button("📈 Equity Research", use_container_width=True,
                 type="primary" if st.session_state.app_mode == "equity" else "secondary"):
        st.session_state.app_mode = "equity"
        st.rerun()
with c_ipo:
    if st.button("🚀 IPO Analysis", use_container_width=True,
                 type="primary" if st.session_state.app_mode == "ipo" else "secondary"):
        st.session_state.app_mode = "ipo"
        st.rerun()

if st.session_state.app_mode == "equity":
    st.info("Equity mode — listed stocks via FMP/yfinance. Verdicts are research screens, not advice.")
    stock_input = st.text_input("Stock name or ticker (e.g. RELIANCE, TCS.NS)", "")
    run = st.button("Analyse Equity", type="primary")
    if run and stock_input.strip():
        with st.spinner("Fetching & modelling..."):
            resolved = resolve_name_to_ticker(stock_input.strip())
            if not resolved:
                st.error("Could not resolve ticker.")
            else:
                try:
                    metrics = fetch_stock_data(resolved, stock_input.strip())
                except Exception as e:
                    st.error(f"Data fetch failed: {e}")
                    metrics = None
                if metrics:
                    st.session_state["last_equity_metrics"] = metrics
    metrics = st.session_state.get("last_equity_metrics")
    if metrics:
        pred = metrics.get("predictive") or {}
        currency = metrics.get("currency") or "₹"
        name = metrics.get("name") or "—"
        price = metrics.get("price")
        vc = rating_color(pred.get("verdict", "OBSERVE"))
        st.markdown(f"""
        <div class="swf-card">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <div style="color:{MUTED};font-size:0.85em;">Equity Research</div>
              <div style="font-size:1.5em;font-weight:800;">{html_escape(str(name))}</div>
              <div style="color:{MUTED};">{html_escape(str(metrics.get('sector','')))} · {html_escape(str(metrics.get('industry','')))}</div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:2em;font-weight:900;color:{vc};">{html_escape(str(pred.get('verdict','—')))}</div>
              <div style="color:{MUTED};">Composite {pred.get('composite_score','—')}/100</div>
            </div>
          </div>
        </div>
        """, unsafe_allow_html=True)

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            custom_metric("Price", f"{currency}{price:,.2f}" if price else "N/A")
        with m2:
            custom_metric("Base Fair Value", f"{currency}{pred.get('base_value'):,.2f}" if pred.get("base_value") else "N/A")
        with m3:
            custom_metric("Bear / Bull",
                (f"{currency}{pred.get('bear_value'):,.0f} / {currency}{pred.get('bull_value'):,.0f}"
                 if pred.get("bear_value") and pred.get("bull_value") else "N/A"))
        with m4:
            custom_metric("Valuation Confidence", pred.get("confidence") or "N/A")

        if pred.get("valuation_models"):
            st.markdown("##### Valuation models")
            st.dataframe(
                [{"Model": k, "Value": v} for k, v in pred["valuation_models"].items()],
                use_container_width=True, hide_index=True,
            )

        audit = pred.get("audit") or metrics.get("audit") or {}
        with st.expander("Why this verdict? (audit trail)", expanded=True):
            st.markdown(
                f"- **Growth used:** {audit.get('growth_used', pred.get('growth_used'))}% "
                f"({audit.get('growth_source', pred.get('growth_source'))})\n"
                f"- **Ke / RFR:** {audit.get('ke', pred.get('discount_rate'))}% / source `{audit.get('rfr_source', metrics.get('rfr_source'))}`\n"
                f"- **Near-term / terminal g:** {audit.get('near_term_growth')}% / {audit.get('terminal_growth')}%\n"
                f"- **Model:** {audit.get('model_used', pred.get('model_used'))}\n"
                f"- **Scores:** fundamental={audit.get('fundamental_score', pred.get('fundamental_score'))}, "
                f"intrinsic={audit.get('intrinsic_score', pred.get('intrinsic_score'))}, "
                f"technical={audit.get('technical_score', pred.get('technical_score'))}\n"
                f"- **Valuation CV / confidence:** {audit.get('valuation_cv')} / {audit.get('valuation_confidence', pred.get('confidence'))}\n"
                f"- **Data completeness:** {metrics.get('data_completeness')}%\n"
            )
            for n in (audit.get("notes") or pred.get("note") or "").split(". ") if isinstance(audit.get("notes"), list) is False else (audit.get("notes") or []):
                if n:
                    st.caption(f"• {n if isinstance(n, str) else str(n)}")
            if isinstance(audit.get("notes"), list):
                for n in audit["notes"]:
                    st.caption(f"• {html_escape(str(n))}")

        warns = metrics.get("warnings") or []
        if warns:
            with st.expander(f"Data-quality warnings ({len(warns)})"):
                for w in warns:
                    st.warning(str(w))

        # Scorecards & checks
        try:
            render_scorecard_badges(
                metrics.get("q_score"), metrics.get("v_score"), metrics.get("f_score"))
        except Exception:
            pass
        if metrics.get("valuation_checks"):
            card("Valuation checklist", render_checks(metrics["valuation_checks"]) if callable(render_checks) else "")
        # Charts
        try:
            if metrics.get("history") is not None:
                st.plotly_chart(price_history_chart(metrics["history"], currency), use_container_width=True)
        except Exception as e:
            st.caption(f"Chart unavailable: {e}")
        if pred.get("base_value") and price:
            try:
                st.plotly_chart(fair_value_bar(price, pred["base_value"], currency), use_container_width=True)
            except Exception:
                pass

        with st.spinner("AI synthesis..."):
            try:
                report = generate_comprehensive_report(metrics, metrics.get("working_ticker") or "")
                card("AI Research Synthesis", f"<p style='color:#c9d1d9;line-height:1.6;white-space:pre-wrap;'>{style_verdict_text(report)}</p>")
            except Exception as e:
                st.caption(f"AI report unavailable: {e}")

        st.caption(
            "Not financial advice. Simplified FCF DCF / residual income are cross-checks. "
            "Scores are uncalibrated heuristics. Always read primary filings."
        )


# ============================================================
# IPO MODE — FULL UI (3-tab: Current / Closed / Upcoming)
# ============================================================
if st.session_state.app_mode == "ipo":
    if "ipo_bucket" not in st.session_state:
        st.session_state.ipo_bucket = None

    st.info(
        "🚀 **IPO Analysis Mode** — Live Indian IPOs from public aggregators. "
        "Current issues can receive a BUY/ABSTAIN screen. Closed & Upcoming show facts only. "
        "Not financial advice."
    )

    if st.session_state.selected_ipo and st.session_state.ipo_detail:
        _render_ipo_detail_view()
    else:
        with st.spinner("Fetching live IPO lists..."):
            cats = fetch_ipo_list_categorized()

        tab_cur, tab_closed, tab_up = st.tabs([
            f"Current ({len(cats.get('current') or [])})",
            f"Closed ({len(cats.get('closed') or [])})",
            f"Upcoming ({len(cats.get('upcoming') or [])})",
        ])
        with tab_cur:
            st.caption("Open for subscription — full screen with GMP, subscription, score & BUY/ABSTAIN.")
            _render_ipo_list_rows(cats.get("current") or [], "current")
        with tab_closed:
            st.caption("Closed / listed — shows listing gains or listing date. No algorithmic verdict.")
            _render_ipo_list_rows(cats.get("closed") or [], "closed")
        with tab_up:
            st.caption("Upcoming — price band & issue facts only. No GMP / subscription / verdict.")
            _render_ipo_list_rows(cats.get("upcoming") or [], "upcoming")

        st.caption(
            f"Source refresh: {cats.get('fetched_at', 'n/a')} · "
            f"{cats.get('sources_note', 'Hybrid IPO sources')}. "
            "GMP is unofficial (aggregator / news / AI extraction)."
        )
