# Athenaeum Financial Intelligence

Modular Streamlit research app for Indian equities and IPOs.

## Run

```bash
cd /path/to/artifacts
streamlit run streamlit_app.py
```

Ensure secrets in `.streamlit/secrets.toml`:

```toml
GEMINI_API_KEY = "..."
FMP_API_KEY = "..."
```

## Package layout

```
streamlit_app.py          # Streamlit entry (UI only)
athenaeum/
  config.py               # colours, thresholds, keyword lists
  utils/helpers.py        # parsing, provenance, formatting
  data/
    equity.py             # FMP + yfinance stock fetch
    rfr.py                # risk-free rate + source label
    ipo.py                # Screener / Chittorgarh / ipomarket IPO engine
  models/
    sector.py             # sector classification
    fundamentals.py       # continuous + checklist scores
    valuation.py          # multi-model valuation
    technical.py          # technical regime score
    pipeline.py           # composite verdict + scenarios
  analysis/
    sentiment.py          # news / order-book signals
  ai/
    reports.py            # Gemini synthesis
  ui/
    components.py         # cards, charts, badges
```

Legacy monolith `athenaeum_app.py` is retained for reference; prefer `streamlit_app.py`.

## Design notes

- Quantitative engine is primary; AI explains, does not override.
- IPO current/closed/upcoming tabs; BUY/ABSTAIN only for current.
- Valuation uses sector-aware weights and simplified FCF DCF (explicitly labeled).
